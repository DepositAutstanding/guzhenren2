#include "gr/world/TwoHeavens.hpp"

#include <algorithm>
#include <cmath>

namespace gr {
namespace {

inline std::uint64_t hh(std::uint64_t x) {
    x ^= x >> 33; x *= 0xff51afd7ed558ccdull;
    x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53ull;
    x ^= x >> 33;
    return x;
}

//  值噪声（与地表同一套手法，保证风格一致）
inline double vn(double x, double y, std::uint64_t seed) {
    const int xi = static_cast<int>(std::floor(x)), yi = static_cast<int>(std::floor(y));
    const double xf = x - xi, yf = y - yi;
    const double u = xf * xf * (3.0 - 2.0 * xf);
    const double v = yf * yf * (3.0 - 2.0 * yf);
    auto g = [&](int a, int b) {
        const std::uint64_t h = hh(seed ^ (static_cast<std::uint64_t>(a) * 374761393ull)
                                        ^ (static_cast<std::uint64_t>(b) * 668265263ull));
        return (h % 10000) / 10000.0;
    };
    const double n00 = g(xi, yi), n10 = g(xi + 1, yi);
    const double n01 = g(xi, yi + 1), n11 = g(xi + 1, yi + 1);
    return (n00 * (1 - u) + n10 * u) * (1 - v) + (n01 * (1 - u) + n11 * u) * v;
}

inline double fbm(double x, double y, std::uint64_t seed) {
    double s = 0.0, amp = 0.5, f = 1.0;
    for (int i = 0; i < 4; ++i) { s += vn(x * f, y * f, seed + i * 1013) * amp; f *= 2.0; amp *= 0.5; }
    return s;
}

} // namespace

HeavenTile& HeavenMap::at(int x, int y) {
    return tiles[static_cast<std::size_t>(y) * w + x];
}
const HeavenTile& HeavenMap::at(int x, int y) const {
    return tiles[static_cast<std::size_t>(y) * w + x];
}

int HeavenMap::reveal(int cx, int cy, int r) {
    int n = 0;
    for (int y = cy - r; y <= cy + r; ++y)
        for (int x = cx - r; x <= cx + r; ++x) {
            if (!inBounds(x, y)) continue;
            HeavenTile& t = at(x, y);
            if (!t.explored) { t.explored = true; ++n; }
        }
    return n;
}

double HeavenMap::exploredRatio() const {
    if (tiles.empty()) return 0.0;
    long long n = 0;
    for (const auto& t : tiles) if (t.explored) ++n;
    return static_cast<double>(n) / static_cast<double>(tiles.size());
}

void HeavenMap::revealAll() {
    for (auto& t : tiles) t.explored = true;
}

// ============================================================================
void generate_heaven_map(HeavenMap& m, const std::string& which, Rng& rng) {
    //
    //  两天比洞天阔大 —— 天在上，覆五域。
    //  尺寸取 96×72，与洞天的「上等」相当。
    //
    m.which = which;
    m.w = 96; m.h = 72;
    m.tiles.assign(static_cast<std::size_t>(m.w) * m.h, HeavenTile{});

    const std::uint64_t seed = 20240906ull + (which == "黑天" ? 11ull
                                            : which == "白天" ? 23ull : 37ull);

    for (int y = 0; y < m.h; ++y) {
        for (int x = 0; x < m.w; ++x) {
            HeavenTile& t = m.at(x, y);

            //  最外一圈为天外虚空（不可达）
            if (x < 1 || y < 1 || x >= m.w - 1 || y >= m.h - 1) {
                t.terrain = HeavenTerrain::Void;
                continue;
            }

            const double n   = fbm(x / 14.0, y / 11.0, seed);
            const double n2  = fbm(x / 7.0 + 40.0, y / 6.0 + 40.0, seed + 7777);

            //
            //  分带（由低到高）：
            //    幽天暗域（低）→ 云海 → 罡风带（高）→ 天柱残迹（极高）
            //
            if (n > 0.78)      t.terrain = HeavenTerrain::PillarRemnant;
            else if (n > 0.62) t.terrain = HeavenTerrain::WindBlast;
            else if (n > 0.30) t.terrain = HeavenTerrain::CloudSea;
            else               t.terrain = HeavenTerrain::GloamVoid;

            //  太古太阳碎片：稀疏点缀（狂蛮魔尊打碎太阳后的残骸）
            if (n2 > 0.90) t.terrain = HeavenTerrain::SunFragment;
            //  天泉：元气凝聚，极少
            else if (n2 < 0.045) t.terrain = HeavenTerrain::SkySpring;
        }
    }

    //
    //  气墙裂隙：四角各一，通五域。
    //  原著黑白两天间的气墙消融、新太阳毁灭后合为幽天 ——
    //  故幽天的裂隙比黑白两天少，取两处。
    //
    const int riftN = (which == "幽天") ? 2 : 4;
    const int riftXs[] = {12, m.w - 13, m.w / 2, 12};
    const int riftYs[] = {12, m.h - 13, 10,     m.h - 13};
    for (int i = 0; i < riftN; ++i) {
        const int rx = riftXs[i], ry = riftYs[i];
        for (int y = ry - 2; y <= ry + 2; ++y)
            for (int x = rx - 2; x <= rx + 2; ++x)
                if (m.inBounds(x, y)) m.at(x, y).terrain = HeavenTerrain::QiWallRift;
    }

    //  入口：自地表裂缝上来的落点，取第一处气墙裂隙
    m.entryX = riftXs[0]; m.entryY = riftYs[0];

    //
    //  定点：太古遗迹与天兽巢穴，按原著「两天有太古遗存与荒兽」推定，
    //  具体位置无明文 —— 标为工程构造，不冒充原著坐标。
    //
    for (int i = 0; i < 5; ++i) {
        const std::uint64_t h = hh(seed + i * 3571ull);
        const int sx = 6 + static_cast<int>(h % static_cast<std::uint64_t>(m.w - 12));
        const int sy = 6 + static_cast<int>((h >> 16) % static_cast<std::uint64_t>(m.h - 12));
        if (!m.inBounds(sx, sy)) continue;
        HeavenTile& t = m.at(sx, sy);
        if (t.terrain == HeavenTerrain::Void) continue;
        t.terrain = (i % 2 == 0) ? HeavenTerrain::RuinSite : HeavenTerrain::Nest;
        CaveSite cs;
        cs.name = std::string(i % 2 == 0 ? "太古遗迹" : "天兽巢穴") + std::to_string(i + 1);
        cs.desc = i % 2 == 0
            ? "太古遗存，或有修行资源与杀招残篇。"
            : "栖于天上的荒兽之巢，非蛊仙不可轻犯。";
        cs.source = "工程构造：原著载两天有太古遗存与荒兽，未给具体坐标";
        cs.canon = false;
        cs.x = sx; cs.y = sy;
        m.sites.push_back(cs);
        t.siteId = static_cast<std::uint8_t>(m.sites.size());
    }
}

} // namespace gr
