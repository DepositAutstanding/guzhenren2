// 聚落与建筑登记
#include "gr/world/Settlement.hpp"

#include <algorithm>

namespace gr {

// ---------------------------------------------------------------- 默认用途
BuildingUse defaultUseOf(BuildingType t) {
    switch (t) {
        case BuildingType::Shop:
        case BuildingType::Market:
        case BuildingType::Auction:
            return BuildingUse::Trade;
        case BuildingType::School:
            return BuildingUse::Learn;
        case BuildingType::Scripture:
            return BuildingUse::Recipe;
        case BuildingType::RefineHall:
        case BuildingType::Alchemy:
            return BuildingUse::Refine;
        case BuildingType::Inn:
            return BuildingUse::Rest;
        case BuildingType::Arena:
            return BuildingUse::Practice;
        case BuildingType::AncestralHall:
            return BuildingUse::Awaken;
        case BuildingType::Mine:
        case BuildingType::HerbGarden:
        case BuildingType::BeastPen:
        case BuildingType::GuPen:
            return BuildingUse::Gather;
        case BuildingType::CityGate:
            return BuildingUse::Passage;
        default:
            return BuildingUse::None;
    }
}

namespace {

//  构造辅助：少写重复字段
struct B {
    const char*  id;
    const char*  name;
    BuildingType type;
    const char*  desc;
    const char*  src;
    bool         canon;
    double       toll      = 0.0;
    int          tech      = 0;
    bool         mortalOnly= false;
};

Building make(const B& b) {
    Building x;
    x.id      = b.id;
    x.name    = b.name;
    x.type    = b.type;
    x.use     = defaultUseOf(b.type);
    x.desc    = b.desc;
    x.source  = b.src;
    x.canon   = b.canon;
    x.toll    = b.toll;
    x.teachesTechnique = b.tech;
    x.mortalOnly = b.mortalOnly;
    return x;
}

std::vector<Building> build(const std::vector<B>& bs) {
    std::vector<Building> v;
    for (const auto& b : bs) v.push_back(make(b));
    return v;
}

} // namespace

// ---------------------------------------------------------------- 登记
SettlementRegistry::SettlementRegistry() {
    //
    //  登记原则：
    //    1. 可核验者标 canon=true 并写出处；原著未载者标 false。
    //    2. 建筑形制随域而异 —— 南疆高脚吊楼、北原帐篷、
    //       西漠土堡、东海码头，不可五域一套。
    //    3. 监天塔已粉碎（第五卷末），不登记为完好建筑。
    //

    // ============================================================ 南疆
    {
        Settlement s;
        s.id = "guyue"; s.name = "古月山寨（冰封废墟）";
        s.landmarkId = "qingmaoshan";   // 青茅山
        s.domain = Domain::NanJiang;
        s.scale = Settlement::Scale::Village;
        s.canon = true;
        s.ruined = true;
        s.desc = "青茅山上的古月家族山寨。第一卷白凝冰自爆北冥冰魄体，"
                 "冰川自山顶覆盖至山脚，三寨尽没，此处已成冰封废墟。"
                 "原著形制仍存于记述：山腰至山脚遍布高脚吊楼，中央五层家主阁。";
        s.source = "原著第一章：古月山寨形制；第一卷末：白凝冰自爆化为冰域绝地";
        s.buildings = build({
            {"guyue_stilt", "高脚吊楼群", BuildingType::StiltHouse,
             "依山而建的木构吊脚楼，自山腰延至山脚，入夜万点微光。",
             "原著第一章：一座座高脚吊楼，数千规模", true},
            {"guyue_lord", "五层家主阁", BuildingType::LordPavilion,
             "山寨最中央的大气楼阁，五层高，常年由精锐重兵把守。",
             "原著：山寨中央五层家主阁，重兵把守", true},
            {"guyue_hall", "宗祖祠堂", BuildingType::AncestralHall,
             "三层漆黑台案供奉先祖牌位，两侧赤铜香炉香烟袅袅；"
             "开窍大典前族长率家老于此祈祷。",
             "原著第1—2集：宗祖祠堂、开窍大典", true,
             0.0, 0, true},
            {"guyue_school", "学堂", BuildingType::School,
             "家老讲学之所，可习得炼蛊手法。",
             "工程设定：家族学堂", false, 0.0, 1},
            {"guyue_refine", "炼蛊房", BuildingType::RefineHall,
             "族人开炉炼蛊之处，火候器具齐备。",
             "工程设定", false},
            {"guyue_pen", "养蛊房", BuildingType::GuPen,
             "豢养族中蛊虫，按时投食。",
             "工程设定", false},
            {"guyue_shop", "通幽商铺", BuildingType::Shop,
             "买卖蛊虫的店铺。牌匾高悬，内有雅室、檀木桌椅、雕梁画栋，"
             "透过窗棂可见庭院青木红花。",
             "原著第408集：通幽商铺，买卖蛊虫", true},
            {"guyue_arena", "演武场", BuildingType::Arena,
             "族中子弟切磋演武之地。", "工程设定", false},
        });
        all_.push_back(s);
    }

    //
    //  百家寨：南疆出生点聚落。
    //  青茅山已毁，古月山寨成废墟，故出生地另设此寨 ——
    //  形制依南疆山寨（依山高脚吊楼、中央楼阁、宗祖祠堂），
    //  属工程设定，原著未见此寨名。
    //
    {
        Settlement s;
        s.id = "baijia"; s.name = "百家寨";
        s.landmarkId = "baijiazhai";
        s.domain = Domain::NanJiang;
        s.scale = Settlement::Scale::Village;
        s.canon = false;
        s.source = "工程设定：青茅山已毁，另设南疆出生寨（形制取南疆山寨）";
        s.desc = "十万大山外缘的山寨，依山而建，高脚吊楼错落。"
                 "族中孤儿于此开窍入道。";
        s.buildings = build({
            {"bj_stilt", "高脚吊楼群", BuildingType::StiltHouse,
             "依山而建的木构吊脚楼，自山腰延至山脚。",
             "工程设定：取南疆山寨形制（原著古月山寨即此形制）", false},
            {"bj_lord", "寨主阁", BuildingType::LordPavilion,
             "山寨中央的楼阁，寨主议事与藏珍之处。",
             "工程设定：取南疆山寨形制", false},
            {"bj_hall", "宗祖祠堂", BuildingType::AncestralHall,
             "供奉先祖牌位，开窍大典前族长率家老于此祈祷。",
             "工程设定：取南疆山寨形制（原著开窍大典于宗祖祠堂）", false,
             0.0, 0, true},
            {"bj_school", "学堂", BuildingType::School,
             "家老讲学之所，可习得炼蛊手法。", "工程设定", false, 0.0, 1},
            {"bj_refine", "炼蛊房", BuildingType::RefineHall,
             "族人开炉炼蛊之处。", "工程设定", false},
            {"bj_pen", "养蛊房", BuildingType::GuPen,
             "豢养族中蛊虫。", "工程设定", false},
            {"bj_shop", "杂货铺", BuildingType::Shop,
             "买卖蛊虫与日用之物。", "工程设定", false},
        });
        all_.push_back(s);
    }

    {
        Settlement s;
        s.id = "shangjia"; s.name = "商家城";
        s.landmarkId = "shangliangshan";// 商量山
        s.domain = Domain::NanJiang;
        s.scale = Settlement::Scale::City;
        s.canon = true;
        s.desc = "南疆财富第一。整座城就是一座立体的大山，"
                 "覆盖商量山山体，分外城与多重内城。";
        s.source = "原著第408集：整个商家城就是一座立体的大山";
        s.buildings = build({
            {"sj_gate3", "第三内城关卡", BuildingType::CityGate,
             "入第三内城须缴 600 块元石。守卫蛊师头领为三转修为。",
             "原著第408集：缴纳600块元石，守卫头领三转", true, 600.0},
            {"sj_star", "星星石建筑群", BuildingType::Starstone,
             "第三内城全以星星石砌成，黑暗中散发璀璨星光，"
             "连街道都铺着星星石石板，入夜视野清明。",
             "原著第408集：建筑石料采用星星石，街道亦然", true},
            {"sj_pillar", "螺旋巨柱", BuildingType::Watchtower,
             "街道每隔约五百步矗立一根需数人合抱的巨型圆柱，"
             "柱身塑螺旋上升石梯，外侧设护栏，连通立体山城的各层。",
             "原著第408集：每隔五百步的巨型圆柱与螺旋石梯", true},
            {"sj_shop", "通幽商铺", BuildingType::Shop,
             "买卖蛊虫的店铺，雅室待客，檀木桌椅、字画挂壁。",
             "原著第408集：通幽商铺", true},
            {"sj_market", "坊市", BuildingType::Market,
             "内外城皆有摊位，货通五域。", "工程设定", false},
            {"sj_auction", "拍卖场", BuildingType::Auction,
             "珍蛊仙材竞卖之所。", "工程设定", false},
            {"sj_inn", "客栈", BuildingType::Inn,
             "落脚休整之处。", "工程设定", false},
            {"sj_school", "学堂", BuildingType::School,
             "商家讲习炼蛊手法之所。", "工程设定", false, 0.0, 2},
            {"sj_script", "藏经阁", BuildingType::Scripture,
             "收罗各方蛊方，可在此查访求得。", "工程设定", false},
            {"sj_mine", "矿场", BuildingType::Mine,
             "山体矿脉采掘，出星星石、火炭石等。", "工程设定", false},
        });
        all_.push_back(s);
    }

    // ============================================================ 北原
    {
        Settlement s;
        s.id = "wangting"; s.name = "王庭福地";
        s.landmarkId = "wangtingfudi";
        s.domain = Domain::BeiYuan;
        s.scale = Settlement::Scale::Capital;
        s.canon = true;
        s.desc = "北原权力核心，黄金家族会盟之所。";
        s.source = "地理研究：北原权力核心";
        s.buildings = build({
            {"wt_palace", "王庭大帐", BuildingType::Palace,
             "黄金家族议事的核心大帐，诸部会盟于此。",
             "工程设定：北原游牧形制", false},
            {"wt_tent", "帐篷群", BuildingType::Tent,
             "北原游牧居所，随部族迁徙。", "工程设定：北原形制", false},
            {"wt_beast", "兽栏", BuildingType::BeastPen,
             "豢养战兽与坐骑。", "工程设定", false},
            {"wt_arena", "演武场", BuildingType::Arena,
             "部族勇士比斗之所。", "工程设定", false},
            {"wt_market", "坊市", BuildingType::Market,
             "皮毛、兽材、蛊虫交易。", "工程设定", false},
            {"wt_school", "学堂", BuildingType::School,
             "传授炼蛊手法。", "工程设定", false, 0.0, 4},
        });
        all_.push_back(s);
    }

    {
        Settlement s;
        s.id = "yinliu"; s.name = "阴流巨城";
        s.landmarkId = "yinliujucheng";
        s.domain = Domain::BeiYuan;
        s.scale = Settlement::Scale::City;
        s.canon = true;
        s.desc = "僵盟所据的巨城，为霸占北原地沟而建。";
        s.source = "地理研究：阴流巨城为霸占北原僵盟地沟而建";
        s.buildings = build({
            {"yl_gate", "城门关卡", BuildingType::CityGate,
             "入城须纳例钱。", "工程设定", false, 100.0},
            {"yl_prison", "牢房", BuildingType::Prison,
             "阴森牢狱。", "工程设定", false},
            {"yl_market", "坊市", BuildingType::Market,
             "尸蛊、阴材交易。", "工程设定", false},
            {"yl_inn", "客栈", BuildingType::Inn, "落脚之处。", "工程设定", false},
            {"yl_script", "藏经阁", BuildingType::Scripture,
             "阴私蛊方收罗处。", "工程设定", false},
        });
        all_.push_back(s);
    }

    // ============================================================ 中洲
    {
        Settlement s;
        s.id = "lingyuan"; s.name = "灵缘斋";
        s.landmarkId = "lingyuanzhai";
        s.domain = Domain::ZhongZhou;
        s.scale = Settlement::Scale::Sect;
        s.canon = true;
        s.desc = "中洲十大古派之一，正道宗门。";
        s.source = "地理研究：中洲十大古派";
        s.buildings = build({
            {"ly_palace", "宗门大殿", BuildingType::Palace,
             "宗门议事与传法之所。", "工程设定", false},
            {"ly_script", "藏经阁", BuildingType::Scripture,
             "宗门蛊方典藏，非弟子不得轻入。", "工程设定", false},
            {"ly_school", "学堂", BuildingType::School,
             "传法授业，习炼蛊手法。", "工程设定", false, 0.0, 3},
            {"ly_refine", "炼蛊房", BuildingType::RefineHall,
             "弟子开炉炼蛊。", "工程设定", false},
            {"ly_arena", "演武场", BuildingType::Arena, "弟子切磋。", "工程设定", false},
            {"ly_garden", "药园", BuildingType::HerbGarden,
             "栽培灵草。", "工程设定", false},
        });
        all_.push_back(s);
    }

    {
        Settlement s;
        s.id = "dijun"; s.name = "帝君城";
        s.landmarkId = "dijuncheng";
        s.domain = Domain::ZhongZhou;
        s.scale = Settlement::Scale::City;
        s.canon = false;
        s.desc = "中洲大城。第五卷末宿命蛊摧毁、监天塔粉碎后，"
                 "此处出现一道新的地沟并蔓延。";
        s.source = "地理研究：帝君城地沟（五域地脉融合所致，属该城个案）";
        s.buildings = build({
            {"dj_gate", "城门关卡", BuildingType::CityGate,
             "入城须纳例钱。", "工程设定", false, 80.0},
            {"dj_rift", "地沟裂口", BuildingType::Watchtower,
             "宿命蛊摧毁后新生的地沟，自城中裂开并向外蔓延，"
             "已设栅栏围禁。",
             "地理研究：帝君城地沟为五域地脉融合所致的个案", true},
            {"dj_market", "坊市", BuildingType::Market, "百货云集。", "工程设定", false},
            {"dj_inn", "客栈", BuildingType::Inn, "落脚休整。", "工程设定", false},
            {"dj_school", "学堂", BuildingType::School,
             "讲习炼蛊。", "工程设定", false, 0.0, 1},
        });
        all_.push_back(s);
    }

    // ============================================================ 西漠
    {
        Settlement s;
        s.id = "tianlu"; s.name = "天露绿洲";
        s.landmarkId = "tianlu";
        s.domain = Domain::XiMo;
        s.scale = Settlement::Scale::Town;
        s.canon = true;
        s.desc = "西漠绿洲之一，人口与商路节点。";
        s.source = "地理研究：西漠绿洲之一，人口与商路节点";
        s.buildings = build({
            {"tl_fort", "土堡", BuildingType::EarthFort,
             "夯土垒筑的堡垒，抵御风沙与匪患。", "工程设定：西漠形制", false},
            {"tl_post", "驿站", BuildingType::Post,
             "商旅歇脚换马之处，连通各绿洲。", "工程设定", false},
            {"tl_market", "集市", BuildingType::Market,
             "绿洲集市，以水与粮为贵。", "工程设定", false},
            {"tl_inn", "客栈", BuildingType::Inn, "落脚之处。", "工程设定", false},
            {"tl_mine", "矿场", BuildingType::Mine,
             "戈壁采掘。", "工程设定", false},
        });
        all_.push_back(s);
    }

    {
        Settlement s;
        s.id = "fangjia"; s.name = "房家";
        s.landmarkId = "fangjia";
        s.domain = Domain::XiMo;
        s.scale = Settlement::Scale::Town;
        s.canon = true;
        s.desc = "西漠十四家族之一，偷道传承。";
        s.source = "地理研究：西漠十四家族之一";
        s.buildings = build({
            {"fj_mansion", "族长府", BuildingType::Mansion,
             "家族核心居所。", "工程设定", false},
            {"fj_hall", "宗祖祠堂", BuildingType::AncestralHall,
             "祭祀先祖，族人开窍亦于此。", "工程设定", false, 0.0, 0, true},
            {"fj_script", "藏经阁", BuildingType::Scripture,
             "偷道蛊方典藏。", "工程设定", false},
            {"fj_school", "学堂", BuildingType::School,
             "传授手法。", "工程设定", false, 0.0, 5},
        });
        all_.push_back(s);
    }

    // ============================================================ 东海
    {
        Settlement s;
        s.id = "qingyue"; s.name = "青岳家";
        s.landmarkId = "qingyuejia";
        s.domain = Domain::DongHai;
        s.scale = Settlement::Scale::Town;
        s.canon = true;
        s.desc = "东海八大家之一，据海域而立。";
        s.source = "地理研究：东海八大家，家族据海域";
        s.buildings = build({
            {"qy_dock", "船坞码头", BuildingType::Dock,
             "泊船修造之所，出海的起点。", "工程设定：东海形制", false},
            {"qy_mansion", "族长府", BuildingType::Mansion,
             "临海而建的府邸。", "工程设定", false},
            {"qy_market", "坊市", BuildingType::Market,
             "海货与蛊虫交易。", "工程设定", false},
            {"qy_school", "学堂", BuildingType::School,
             "传授手法。", "工程设定", false, 0.0, 3},
            {"qy_pen", "养蛊房", BuildingType::GuPen,
             "豢养海中蛊虫。", "工程设定", false},
        });
        all_.push_back(s);
    }

    {
        Settlement s;
        s.id = "longjing"; s.name = "龙鲸乐土";
        s.landmarkId = "longjingleitu";
        s.domain = Domain::DongHai;
        s.scale = Settlement::Scale::City;
        s.canon = true;
        s.desc = "苍蓝龙鲸关联洞天，跨域交易市场。";
        s.source = "地理研究：龙鲸乐土，跨域市场功能的交易洞天";
        s.buildings = build({
            {"lj_market", "跨域坊市", BuildingType::Market,
             "五域货通，异域物种在此交易。", "工程设定", false},
            {"lj_auction", "拍卖场", BuildingType::Auction,
             "珍品竞卖。", "工程设定", false},
            {"lj_inn", "客栈", BuildingType::Inn, "落脚之处。", "工程设定", false},
            {"lj_script", "藏经阁", BuildingType::Scripture,
             "各方蛊方汇流。", "工程设定", false},
        });
        all_.push_back(s);
    }
}

const Settlement* SettlementRegistry::byLandmark(const std::string& id) const {
    if (id.empty()) return nullptr;
    for (const auto& s : all_)
        if (s.landmarkId == id) return &s;
    return nullptr;
}

const Settlement* SettlementRegistry::byId(const std::string& id) const {
    if (id.empty()) return nullptr;
    for (const auto& s : all_)
        if (s.id == id) return &s;
    return nullptr;
}

std::size_t SettlementRegistry::buildingCount() const {
    std::size_t n = 0;
    for (const auto& s : all_) n += s.buildings.size();
    return n;
}

} // namespace gr
