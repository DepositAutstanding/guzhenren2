// 世界地图实现
#include "gr/world/WorldMap.hpp"
#include "gr/core/CanonNumbers.hpp"

#include <algorithm>
#include <cmath>

namespace gr {

WorldMap::WorldMap() {
    // 开局：疯魔窟大战结束后，默认平静期
    gale_.reset(GalePhase::Calm);
    climate_.warmSeason = true;
    climate_.phase      = DayPhase::Day;
}

void WorldMap::buildCanonWorld(Rng& rng, int randomCaveCount) {
    caves_.clear();
    caveOrder_.clear();

    // 时间基线固定第六卷开局：两天已非静态两层。
    // 幽魂吞噬黑天天灵、攻日致太阳爆裂、白天天灵与天脉节点受损。
    twoHeavens_.setVolumeSixOpening();

    for (auto& c : build_canon_cave_table()) addCave(c);
    for (auto& c : generate_random_caves(rng, randomCaveCount)) addCave(c);
}

void WorldMap::addCave(const CaveParadise& c) {
    if (caves_.find(c.siteId) != caves_.end()) return;  // 原著有名实例唯一
    caves_.emplace(c.siteId, c);
    caveOrder_.push_back(c.siteId);
}

const CaveParadise* WorldMap::findCave(const std::string& siteId) const {
    auto it = caves_.find(siteId);
    return it == caves_.end() ? nullptr : &it->second;
}

CaveParadise* WorldMap::findCaveMut(const std::string& siteId) {
    auto it = caves_.find(siteId);
    return it == caves_.end() ? nullptr : &it->second;
}

std::vector<const CaveParadise*> WorldMap::allCaves() const {
    std::vector<const CaveParadise*> v;
    v.reserve(caveOrder_.size());
    for (const auto& id : caveOrder_) v.push_back(&caves_.at(id));
    return v;
}

std::vector<const CaveParadise*> WorldMap::cavesIn(RealmLayer l) const {
    std::vector<const CaveParadise*> v;
    for (const auto& id : caveOrder_) {
        const CaveParadise& c = caves_.at(id);
        if (c.layer == l) v.push_back(&c);
    }
    return v;
}

void WorldMap::advanceTime(Tick dt) {
    for (Tick i = 0; i < dt; ++i) {
        ++now_;
        gale_.advance();

        // 世界自然昼夜/季节轮换（简化：以刻度驱动，非永久固定）
        int dayCycle = static_cast<int>(now_ % 40);
        if      (dayCycle < 4)  climate_.phase = DayPhase::Dawn;
        else if (dayCycle < 20) climate_.phase = DayPhase::Day;
        else if (dayCycle < 26) climate_.phase = DayPhase::Dusk;
        else if (dayCycle < 34) climate_.phase = DayPhase::Night;
        else                    climate_.phase = DayPhase::DeepNight;

        // 极夜：长周期事件
        climate_.polarNight = (now_ % 400) >= 360;
        // 暴风雪：北原常见天气，随机但可复现（用 tick 派生，不消耗 rng 序列）
        climate_.blizzard = ((now_ * 2654435761u) % 17u) == 0u;
        // 暖季
        climate_.warmSeason = (now_ % 800) < 500;

        // 万劫 / 灾劫倒计时
        for (auto& id : caveOrder_) {
            CaveParadise& c = caves_[id];
            if (c.tribulationTimer > 0) {
                --c.tribulationTimer;
            }
        }
    }
}

Result<void> WorldMap::tryCrossWombWall(WombWallPrivilege priv, bool isPlayer) {
    if (isPlayer) {
        // 铁律：世界胎壁不可突破（仅剧情特例，且玩家永不适用）
        return Result<void>::fail(Err::WombWallImpassable,
                                  "玩家不可突破世界胎壁（NPC 剧情特例不开放给玩家）");
    }
    if (priv == WombWallPrivilege::StoryOnlyZunZhe) {
        return Result<void>::success("剧情限定：特殊尊者级存在短暂触碰胎壁");
    }
    return Result<void>::fail(Err::WombWallImpassable,
                              "99.99% 的蛊师、蛊仙永远无法穿透世界胎壁");
}

Result<TraverseCost> WorldMap::evaluateTraversal(const Location& from,
                                                 const Location& to,
                                                 Rank rank) const {
    // 世界胎壁优先判定：世界绝对屏障，不可突破（仅剧情特例，玩家永不适用）
    if (to.layer == RealmLayer::WorldWombWall) {
        return Result<TraverseCost>::fail(Err::WombWallImpassable,
                                          "世界胎壁为世界绝对屏障，不可突破");
    }
    // 界外空域已被彻底删除：全地图所有空间全部收纳在两天五域之内
    if (!isValidLayer(to.layer)) {
        return Result<TraverseCost>::fail(Err::VoidSpaceRemoved,
                                          "目标层级非法：界外空域已被彻底删除");
    }

    TraverseCost cost;
    double base = 1.0;

    // 跨层：五域 → 两天 需穿越位面屏障
    if (isHeavenLayer(from.layer) != isHeavenLayer(to.layer)) base += 1.5;

    // 白天天罡罡风：动态天气，仅白天罡风带生效
    if (to.layer == RealmLayer::WhiteHeaven || from.layer == RealmLayer::WhiteHeaven) {
        cost.essence += base * gale_.traverseCostMultiplier() * 10.0;
        if (gale_.isLethalTo(rank)) {
            cost.lethal = true;
            cost.note   = std::string("暴风灾期：") + to_string(rank) + " 以下被罡风撕裂重创";
            return Result<TraverseCost>::fail(Err::StormFatal, cost.note);
        }
        if (gale_.phase() != GalePhase::Calm) {
            cost.daoMarks += gale_.traverseDifficulty() * 50.0;
            cost.note = std::string("天罡罡风·") + to_string(gale_.phase());
        } else {
            cost.note = "平静期：可安全穿行白天洞天之间";
        }
    }

    // 黑天/白天位面压制：凡俗生灵平等承受
    if (isHeavenLayer(to.layer) && !is_immortal_rank(rank)) {
        cost.essence += 20.0;
        cost.note += "；位面压制（凡俗重耗）";
    }

    // ---- 五域界壁：跨域须承受界壁压制（层次越高阻碍越强）----
    //  界壁是空间摩擦力而非国境线篱笆。对凡人与低阶蛊师影响相对有限；
    //  对六转以上蛊仙、仙蛊屋、大规模军团，跨域会变成消耗战。
    if (from.domain != to.domain) {
        DomainWallCost wall = evaluateDomainWall(from.domain, to.domain, rank);
        if (!wall.penetrable) {
            return Result<TraverseCost>::fail(Err::InsufficientEssence,
                                              "界壁压制过强，无法穿越");
        }
        cost.essence  = (cost.essence + base * 5.0) * wall.essenceMul;
        cost.daoMarks *= wall.daoMarksMul;
        if (!cost.note.empty()) cost.note += "；";
        cost.note += std::string(to_string(from.domain)) + "→" +
                     to_string(to.domain) + " 跨越「" +
                     domainWallName(from.domain) + "／" + domainWallName(to.domain) +
                     "」（" + wall.note + "）";
        return Result<TraverseCost>::success(cost, cost.note);
    }

    cost.essence += base * 5.0;
    return Result<TraverseCost>::success(cost, cost.note);
}

std::vector<StatusEffect> WorldMap::evaluateEnvironment(const Location& loc,
                                                        Domain bornDomain) const {
    std::vector<StatusEffect> out;

    // ---- 黑天 / 白天：天地规则压制，无本土免疫 ----
    if (isHeavenLayer(loc.layer)) {
        StatusEffect s;
        s.kind      = StatusKind::HeavenSuppression;
        s.name      = std::string(to_string(loc.layer)) + "位面压制";
        s.magnitude = 0.6;
        apply_status(out, s);

        if (loc.layer == RealmLayer::WhiteHeaven && gale_.phase() != GalePhase::Calm) {
            StatusEffect g;
            g.kind      = StatusKind::TiangangGale;
            g.name      = std::string("天罡罡风·") + to_string(gale_.phase());
            g.magnitude = gale_.traverseDifficulty();
            apply_status(out, g);
        }
        return out;  // 位面内不再叠加五域环境 DEBUFF
    }

    // ---- 北原严寒：仅极夜 / 暴风雪 / 深夜极寒时段触发 ----
    if (loc.domain == Domain::BeiYuan &&
        beiyuan_cold_regions().count(loc.region) > 0 &&
        climate_.triggersBeiYuanCold()) {
        StatusEffect s;
        s.kind      = StatusKind::BeiYuanSevereCold;
        s.name      = "北原严寒";
        s.magnitude = 1.0;
        if (bornDomain == Domain::BeiYuan) {
            s.magnitude *= (1.0 - kNativeImmunityRatio);  // 本土高额免疫
            s.name += "（北原出身·高额免疫）";
        }
        apply_status(out, s);
    }

    // ---- 南疆瘴气：仅固定刷新在特定瘴气谷 / 毒泽 / 原始深林禁地 ----
    if (loc.domain == Domain::NanJiang &&
        miasma_regions().count(loc.region) > 0) {
        StatusEffect s;
        s.kind      = StatusKind::NanJiangMiasma;
        s.name      = "南疆瘴气";
        s.magnitude = 1.0;
        if (bornDomain == Domain::NanJiang) {
            s.magnitude *= (1.0 - kNativeImmunityRatio);
            s.name += "（南疆出身·高额免疫）";
        }
        apply_status(out, s);
    }

    return out;
}

WorldMap::QiYield WorldMap::collectQi(const Location& loc, double effort) const {
    QiYield y;
    // 洞天内部：按洞天自身产出
    if (!loc.siteId.empty()) {
        if (const CaveParadise* c = findCave(loc.siteId)) {
            y.heaven += c->qiYieldHeaven * effort;
            y.earth  += c->qiYieldEarth  * effort;
            y.human  += c->qiYieldHuman  * effort;
            return y;
        }
    }
    // 野外：5.2 三气获取闭环
    //  天气积累：黑天 / 天道秘境
    //  地气积累：五域地脉 / 福地
    //  人气积累：白天 / 人道势力布局
    if (loc.layer == RealmLayer::BlackHeaven) {
        y.heaven += 3.0 * effort;
        y.earth  += 0.5 * effort;
    } else if (loc.layer == RealmLayer::WhiteHeaven) {
        y.human  += 3.0 * effort;
        y.heaven += 0.5 * effort;
    } else {
        y.earth  += 3.0 * effort;
        y.human  += (loc.region == "城寨" || loc.region == "集市" ? 1.5 : 0.3) * effort;
    }
    return y;
}

// ---------------------------------------------------------------------------
//  五域界壁（地理研究文档第三章）
// ---------------------------------------------------------------------------
const char* WorldMap::domainWallName(Domain d) {
    switch (d) {
        case Domain::ZhongZhou: return "中洲圣贤界壁";
        case Domain::NanJiang:  return "南疆瘴气界壁";
        case Domain::BeiYuan:   return "北原甘草界壁";
        case Domain::XiMo:      return "西漠狂炎界壁";
        case Domain::DongHai:   return "东海苍水界壁";
        case Domain::None:      return "（两天无域界壁）";
    }
    return "？";
}

WorldMap::DomainWallCost WorldMap::evaluateDomainWall(Domain from, Domain to, Rank r) {
    DomainWallCost c;
    // 同域或涉及「无域属」（两天/域外）：不受域界壁影响
    if (from == to || from == Domain::None || to == Domain::None) {
        c.note = "同域或跨出五域，不受域界壁压制";
        return c;
    }

    // 层次越高，界壁阻碍越强（设定如此，非数值 bug）
    const int rv = rank_value(r);
    double strength = 1.0 + 0.35 * static_cast<double>(rv);   // 每转递增

    // 东海因海潮使部分界壁较薄弱 —— 出入东海的压制较他域轻
    const bool involvesDongHai = (from == Domain::DongHai || to == Domain::DongHai);
    if (involvesDongHai) {
        strength *= 0.70;
        c.note = "东海苍水界壁受海潮影响较薄弱，跨域压制减轻";
    } else {
        c.note = "跨域须承受界壁压制：修为越高，阻碍越强";
    }

    // 凡俗（一至五转）受界壁影响远小于蛊仙，但跨域代价仍不应低于同域
    if (rv < canon::kImmortalRank) strength *= 0.45;
    if (strength < 1.0) strength = 1.0;

    c.essenceMul  = strength;
    c.daoMarksMul = 1.0 + (strength - 1.0) * 0.5;
    c.penetrable  = true;
    return c;
}

WorldMap::DistributionAudit WorldMap::audit() const {
    DistributionAudit a{};
    for (const auto& id : caveOrder_) {
        const CaveParadise& c = caves_.at(id);
        if (c.layer == RealmLayer::WhiteHeaven && c.kind == CaveKind::YirenCave) ++a.whiteHeavenYiren;
        if (c.layer == RealmLayer::WhiteHeaven && c.kind == CaveKind::YizuCave)  ++a.whiteHeavenYizu;
        if (c.layer == RealmLayer::BlackHeaven &&
            (c.kind == CaveKind::HeavenDaoSecret || c.kind == CaveKind::HeavenDaoCave))
            ++a.blackHeavenTiandao;
        if (c.owner == CaveOwnership::FangYuanSwallowed) ++a.fangYuanOwned;
        if (c.owner == CaveOwnership::TianTingOccupied)  ++a.tianTingOwned;
        if (c.fixedInstance) ++a.fixedInstances; else ++a.randomized;
        if (!DistributionRule::kindAllowedInLayer(c.kind, c.layer)) ++a.illegalPlacement;
        if (c.layer == RealmLayer::WorldWombWall) ++a.voidSpaceCaves;
    }
    return a;
}

} // namespace gr
