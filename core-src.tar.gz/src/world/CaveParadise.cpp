// 洞天福地实现（含开局原著实例表与随机生成规则）
#include "gr/world/CaveParadise.hpp"
#include "gr/core/Rng.hpp"

namespace gr {

bool DistributionRule::kindAllowedInLayer(CaveKind k, RealmLayer l) {
    switch (k) {
        // 异人/异族洞天：大量分布于白天，亦可见于五域与黑天（黑天少量）
        case CaveKind::YirenCave:
        case CaveKind::YizuCave:
            return l == RealmLayer::WhiteHeaven ||
                   l == RealmLayer::BlackHeaven ||
                   l == RealmLayer::MortalSurface ||
                   l == RealmLayer::MortalUnderground;
        // 天道原生秘境 / 天道洞天：黑天为主
        case CaveKind::HeavenDaoSecret:
        case CaveKind::HeavenDaoCave:
            return l == RealmLayer::BlackHeaven || l == RealmLayer::WhiteHeaven;
        // 人道天庭洞天集群：白天
        case CaveKind::TianTingCluster:
            return l == RealmLayer::WhiteHeaven;
        // 原著有名实例、太古七天碎片、幽天魔渊：散落两天五域
        default:
            return l != RealmLayer::WorldWombWall;
    }
}

// ---------------------------------------------------------------------------
//  第六卷开局（疯魔窟大战结束后）洞天实例表
//  —— 原著有名洞天福地：固定唯一实例，绝不随机生成
//  —— 方源 / 天庭已占领部分白天异人洞天，状态与开局一致
//
//  source 字段严格区分三类来源，避免把工程占位当作原著事实：
//    [原著定点] 第六卷卷初研究报告 / 需求说明书可直接核验
//    [需求构造] 需求说明书 3.1 要求「白天大量异人洞天、部分被方源吞并、
//               部分被天庭占领」，但未给出具体名称 —— 按异人族名填充
//    [工程占位] 既非原著称定点、亦非需求指定，仅为机制演示需要
// ---------------------------------------------------------------------------

// ============================================================================
//  福地等级
//
//  数值皆出原著（第三卷 291 节），不臆造。
//  光阴流速一项原著说「仙窍内时间流逝远快于外界」，
//  但除「一比十六」（方源力道仙窍）外未给通例，
//  故此处按等级递增取值，标为工程推定。
// ============================================================================
CaveGradeInfo cave_grade_info(CaveGrade g) {
    CaveGradeInfo i;
    i.grade = g;
    switch (g) {
        case CaveGrade::Lower:
            i.minMu = 100.0; i.maxMu = 300.0;
            i.essencePerYear = 12;
            i.timeRatio = 4.0;
            i.mapW = 48; i.mapH = 36;
            i.source = "原著：下等福地方圆至多三百万亩，年产仙元十余颗";
            break;
        case CaveGrade::Middle:
            i.minMu = 400.0; i.maxMu = 600.0;
            i.essencePerYear = 22;
            i.timeRatio = 8.0;
            i.mapW = 64; i.mapH = 48;
            i.source = "原著：中等福地四百万到六百万亩，年产仙元二十余颗";
            break;
        case CaveGrade::Upper:
            i.minMu = 700.0; i.maxMu = 900.0;
            i.essencePerYear = 32;
            i.timeRatio = 12.0;
            i.mapW = 96; i.mapH = 72;
            i.source = "原著：上等福地七百万到九百万亩，年产仙元三十余颗，"
                       "二气交感可将凡蛊点化为仙蛊";
            break;
        case CaveGrade::Special:
            i.minMu = 1000.0; i.maxMu = 2000.0;
            i.essencePerYear = 52;
            i.timeRatio = 16.0;
            i.mapW = 128; i.mapH = 96;
            i.source = "原著：特等福地一千万到两千万亩，年产仙元五十余颗，"
                       "十绝体升仙方得（黑楼兰即是一例）";
            break;
    }
    return i;
}

CaveGrade cave_grade_by_area(double mu) {
    if (mu >= 1000.0) return CaveGrade::Special;
    if (mu >= 700.0)  return CaveGrade::Upper;
    if (mu >= 400.0)  return CaveGrade::Middle;
    return CaveGrade::Lower;
}

std::vector<CaveParadise> build_canon_cave_table() {
    std::vector<CaveParadise> t;
    auto add = [&t](CaveParadise c) { t.push_back(std::move(c)); };

    // ---------------- 白天：人道天庭洞天集群 ----------------
    { CaveParadise c; c.siteId="tt_central"; c.name="人道天庭洞天集群";
      c.kind=CaveKind::TianTingCluster; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::ZhongZhou; c.region="白天·天庭洞天带";
      c.owner=CaveOwnership::TianTingOccupied; c.ownerTag="天庭";
      c.hasEarthSpirit=true; c.qiYieldHuman=12.0; c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[需求构造] 需求3.1 白天构成：人道天庭洞天集群"; add(c); }

    // ---------------- 白天：被方源吞并掌控的异人洞天 ----------------
    // 豪豨洞天：研究报告明确「气海分身处理豪豨洞天气功果」，为原著定点
    { CaveParadise c; c.siteId="fy_hao_xi"; c.name="豪豨洞天";
      c.kind=CaveKind::YirenCave; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::NanJiang; c.region="白天·异人洞天带";
      c.owner=CaveOwnership::FangYuanSwallowed; c.ownerTag="方源";
      c.qiYieldHeaven=6.0; c.qiYieldEarth=3.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 研究报告3.6：气海分身处理豪豨洞天气功果"; add(c); }

    { CaveParadise c; c.siteId="fy_min_qiang"; c.name="民羌洞天";
      c.kind=CaveKind::YirenCave; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::XiMo; c.region="白天·异人洞天带";
      c.owner=CaveOwnership::FangYuanSwallowed; c.ownerTag="方源";
      c.qiYieldHeaven=5.0; c.qiYieldHuman=2.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[需求构造] 需求3.1：部分异人洞天被方源吞并掌控"; add(c); }

    // ---------------- 白天：被天庭攻占/奴役/驻守的异人洞天 ----------------
    { CaveParadise c; c.siteId="tt_nu_zu"; c.name="女族洞天";
      c.kind=CaveKind::YirenCave; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::DongHai; c.region="白天·异人洞天带";
      c.owner=CaveOwnership::TianTingOccupied; c.ownerTag="天庭";
      c.qiYieldHuman=5.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[需求构造] 需求3.1：部分异人洞天被天庭攻占、奴役、驻守"; add(c); }

    { CaveParadise c; c.siteId="tt_mao_min"; c.name="毛民洞天";
      c.kind=CaveKind::YirenCave; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::ZhongZhou; c.region="白天·异人洞天带";
      c.owner=CaveOwnership::TianTingOccupied; c.ownerTag="天庭";
      c.qiYieldHeaven=3.0; c.qiYieldHuman=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[需求构造] 需求3.1：部分异人洞天被天庭攻占、奴役、驻守"; add(c); }

    // 龙人洞天：龙宫持有者含【吴帅】，而吴帅为方源南疆身份、活动区在南疆。
    // 此前挂东海，与 NPC 表中吴帅 Domain::NanJiang 自相矛盾 —— 已改为南疆以保持一致。
    { CaveParadise c; c.siteId="yz_long_ren"; c.name="龙人洞天";
      c.kind=CaveKind::YizuCave; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::NanJiang; c.region="白天·异族洞天带（南疆上方）";
      c.owner=CaveOwnership::NativeRace; c.ownerTag="龙人族";
      c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[需求构造] 需求3.1：白天大量古老异族、异人洞天；"
               "域属依仙蛊屋表「龙宫·八转奴道·【吴帅】」与 NPC 吴帅南疆身份推定"; add(c); }

    // ---------------- 黑天：天道原生秘境 / 天道洞天 ----------------
    { CaveParadise c; c.siteId="ht_tiandao_1"; c.name="天道原生秘境·无极渊";
      c.kind=CaveKind::HeavenDaoSecret; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·天道秘境带";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=15.0;
      c.hasEarthSpirit=true;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[工程占位] 需求3.1：黑天以天道原生秘境、天道洞天为主（名称非原著定点）"; add(c); }

    { CaveParadise c; c.siteId="ht_tiandao_2"; c.name="天道洞天·星宿遗境";
      c.kind=CaveKind::HeavenDaoCave; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·天道秘境带";
      c.owner=CaveOwnership::TianTingOccupied; c.ownerTag="天庭";
      c.qiYieldHeaven=10.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[工程占位] 需求3.1：黑天天道洞天（名称非原著定点）"; add(c); }

    { CaveParadise c; c.siteId="ht_yizu_xue"; c.name="雪胡洞天（黑天少量异族洞天）";
      c.kind=CaveKind::YizuCave; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·异族飞地";
      c.owner=CaveOwnership::NativeRace; c.ownerTag="雪胡族";
      c.qiYieldHeaven=3.0; c.qiYieldEarth=2.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[需求构造] 需求3.1：黑天含少量异族洞天"; add(c); }

    // ---------------- 原著有名洞天福地（五域，固定唯一实例） ----------------
    // 至尊仙窍：方源的仙窍世界 —— 属「洞天内部」，不属五域任何一域。
    // 【已更正】此前 domain 误设为东海。地理研究明确：逆流河被方源置于至尊仙窍的
    // 「小东海」—— 「小东海」是仙窍内部的复制区域，不是至尊仙窍位于东海地表。
    // 数值口径库：10 层，每层 5000 万亩以上；仙窍∶外界时间流速 60∶1；
    // 仙元产量每年 96 颗（按仙窍时间），换算到外界约每天 16 颗。
    // 注：至尊仙胎为特殊案例，不可当作普通七转生产率。
    { CaveParadise c; c.siteId="cn_zunzhe_xiantiao"; c.name="至尊仙窍（方源）";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::None; c.region="方源自持仙窍（内有小东海等五域式区域）";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="方源";
      c.hasEarthSpirit=true; c.qiYieldHeaven=8.0; c.qiYieldEarth=8.0; c.qiYieldHuman=8.0;
      c.siteClass=SiteClass::CaveInterior;
      c.essenceYieldPerYear=96.0;   // 数值口径库：至尊洞天仙元产量 96 颗/年
      c.outerEssencePerDay=16.0;    // 换算到外界约每天 16 颗（时间流速 60:1）
      c.timeRatio=60.0;             // 仙窍∶外界 = 60∶1
      c.layers=10;                  // 10 层，每层 5000 万亩以上
      c.source="[原著定点] 研究报告2.2、7.2：方源至尊仙窍；地理研究：逆流河置于"
               "仙窍内「小东海」；数值口径库：10层、60:1、96颗/年（外界16颗/天）"; add(c); }

    // 疯魔窟：地理研究文档明确「北原十大凶地」，共九层。
    // 此前误置于中洲 —— 已按研究文档修正为北原。
    // 九层结构：一层外部入口；二层火岩石滩；三层云竹云雾猛兽雾都；
    // 四—六层环境各异（六层有山谷、疯魔三怪）；七—八层近天道梦境；
    // 九层为魔音源头，含元境、书山、九转衍化蛊、疯魔九虚阵。
    { CaveParadise c; c.siteId="cn_fengmo_ku"; c.name="疯魔窟";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalUnderground;
      c.domain=Domain::BeiYuan; c.region="北原·十大凶地";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=6.0;
      c.siteClass=SiteClass::MortalSurface;
      c.floors=9;   // 九层嵌套，非普通山谷
      c.source="[原著定点] 研究报告4.4、资料库：疯魔窟盗天真传所在"; add(c); }

    // 义天山：地理研究明确列于「南疆」，为义天山大战核心。
    // 此前误置于中洲 —— 已按研究文档修正为南疆。
    { CaveParadise c; c.siteId="cn_yitian"; c.name="义天山";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::NanJiang; c.region="南疆·义天山";
      c.owner=CaveOwnership::TianTingOccupied; c.ownerTag="天庭";
      c.siteClass=SiteClass::MortalSurface;
      c.source="[原著定点] 地理研究：义天山属南疆，山岳战场、义天山大战核心；"
               "资料库杀招表亦载此战（换魂／引魂入梦）"; add(c); }

    { CaveParadise c; c.siteId="cn_changshengtian"; c.name="长生天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::BeiYuan; c.region="北原·长生天";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="巨阳仙尊";
      c.qiYieldHuman=9.0;
      c.siteClass=SiteClass::MortalSurface;
      c.source="[原著定点] 资料库仙蛊屋表：镇运天宫、劫运坛【巨阳仙尊】【长生天】"; add(c); }

    { CaveParadise c; c.siteId="cn_baohuangtian"; c.name="宝黄天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::None; c.region="五域共通·宝黄天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHuman=6.0;
      c.siteClass=SiteClass::CaveInterior;
      c.source="[原著定点] 需求9.1「玩家宝黄天跨玩家交易」（资料库未收录该词条）"; add(c); }

    // 南疆·异族洞天带：吴帅接收异族联盟的活动区（研究报告 Table 4「南疆：吴帅活动区」）
    { CaveParadise c; c.siteId="yz_nanjiang_aliance"; c.name="南疆异族联盟洞天";
      c.kind=CaveKind::YizuCave; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::NanJiang; c.region="南疆·异族联盟";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="吴帅（代方源）";
      c.qiYieldHuman=6.0; c.qiYieldEarth=3.0;
      c.siteClass=SiteClass::MortalSurface;
      c.source="[需求构造] 研究报告 Table4：南疆为「人道、异族联盟、吴帅活动区」"; add(c); }

    // ---------------- 地理研究文档点名的两天洞天 ----------------
    // 研究文档「二、太古白天与太古黑天」按「上方白天/黑天」归类著名洞天：
    //   白天：华文洞天、兽灾洞天、闪光洞天
    //   黑天：安魂、冰晶、夜狼、碎骨、大智、乱石、弯月
    // 此为「区域上方位 ＋ 所有权/形成历史」的双重命名，
    // 并不表示每个洞天都属于太古荒兽体内。
    { CaveParadise c; c.siteId="wh_huawen"; c.name="华文洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::ZhongZhou; c.region="白天·华文洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=5.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：白天著名洞天（华文洞天）"; add(c); }

    { CaveParadise c; c.siteId="wh_shouzai"; c.name="兽灾洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::DongHai; c.region="白天·兽灾洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：白天著名洞天（兽灾洞天）"; add(c); }

    { CaveParadise c; c.siteId="ht_anhuen"; c.name="安魂洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·安魂洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=5.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：黑天著名洞天（安魂洞天）"; add(c); }

    { CaveParadise c; c.siteId="ht_bingjing"; c.name="冰晶洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·冰晶洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：黑天著名洞天（冰晶洞天）"; add(c); }

    { CaveParadise c; c.siteId="ht_yelang"; c.name="夜狼洞天";
      c.kind=CaveKind::YizuCave; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·夜狼洞天";
      c.owner=CaveOwnership::NativeRace; c.ownerTag="夜狼族";
      c.qiYieldHeaven=3.0; c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：黑天著名洞天（夜狼洞天）"; add(c); }

    // ---------------- 仙窍内部坐标（易被误当作五域地表）----------------
    // 地理研究文档强调：荡魂山、落魄谷留在琅琊福地内；
    // 逆流河被方源置于至尊仙窍「小东海」。它们是仙窍内坐标，不是五域省份。
    { CaveParadise c; c.siteId="langya_fudi"; c.name="琅琊福地";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::BeiYuan; c.region="原北原月牙湖（影宗突袭后已迁址）";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="毛民";
      c.hasEarthSpirit=true; c.qiYieldEarth=5.0;
      c.siteClass=SiteClass::CaveInterior;
      c.source="[原著定点] 地理研究：原在北原月牙湖，影宗突袭后迁移，"
               "第六卷时已不在原址；灾劫上限为浩劫，不受万劫"; add(c); }

    { CaveParadise c; c.siteId="dh_danghun_shan"; c.name="荡魂山（琅琊福地内）";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::None; c.region="琅琊福地内部";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="琅琊福地";
      c.siteClass=SiteClass::CaveInterior;
      c.source="[原著定点] 地理研究：魂道奇山，原在南疆体系，"
               "后被收于琅琊福地 —— 属仙窍内坐标，非五域地表"; add(c); }

    { CaveParadise c; c.siteId="ns_niliu_he"; c.name="逆流河（至尊仙窍·小东海）";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::None; c.region="至尊仙窍·小东海";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="方源";
      c.siteClass=SiteClass::CaveInterior;
      c.source="[原著定点] 地理研究：宙道/规则型河流，"
               "被方源置于至尊仙窍小东海 —— 仙窍内坐标"; add(c); }

    // 光阴长河：域外宙道至高空间，不等同五域任何可航行河川。
    // 地理研究明确「不宜误标在某域地表」。
    // 注：kind 用 RenownedParadise 而非 HeavenDaoSecret ——
    // 后者受「天道秘境只应在两天」的分布规则约束，
    // 而光阴长河属域外规则空间，其性质由 siteClass 表达，不由 layer 表达。
    { CaveParadise c; c.siteId="gy_guangyin_changhe"; c.name="光阴长河";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::None; c.region="域外·宙道至高空间";
      c.owner=CaveOwnership::Unclaimed;
      c.siteClass=SiteClass::OuterRuleSpace;
      c.source="[原著定点] 地理研究：时间法则空间，红莲线关键；"
               "属域外规则空间，不可误标于五域地表"; add(c); }

    // ---------------- 黑天洞天群（地理研究：安魂、冰晶、夜狼、碎骨、大智、乱石、弯月）----------------
    { CaveParadise c; c.siteId="ht_suigu"; c.name="碎骨洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·碎骨洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：黑天著名洞天（碎骨洞天）"; add(c); }

    { CaveParadise c; c.siteId="ht_dazhi"; c.name="大智洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·大智洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：黑天著名洞天（大智洞天）"; add(c); }

    { CaveParadise c; c.siteId="ht_luanshi"; c.name="乱石洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·乱石洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=3.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：黑天著名洞天（乱石洞天）"; add(c); }

    { CaveParadise c; c.siteId="ht_wanyue"; c.name="弯月洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::BlackHeaven;
      c.domain=Domain::None; c.region="黑天·弯月洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=3.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：黑天著名洞天（弯月洞天）"; add(c); }

    // ---------------- 白天：闪光洞天（地理研究：华文、兽灾、闪光）----------------
    { CaveParadise c; c.siteId="wh_shanguang"; c.name="闪光洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::None; c.region="白天·闪光洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：白天著名洞天（闪光洞天）"; add(c); }

    // ---------------- 王庭福地（北原，与长生天相连）----------------
    // 地理研究明确区分「王庭福地」与「长生天」：
    //   王庭福地：北原权力核心，承担长生天的灾劫排遣功能，
    //             赢得王庭之争的部族可进入其中避灾
    //   长生天  ：北原上方位／天庭型超级洞天体系，巨阳体系最高权力中心
    // 二者不可混为一谈。
    { CaveParadise c; c.siteId="cn_wangting_fudi"; c.name="王庭福地";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::BeiYuan; c.region="北原·王庭福地";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="黄金部族";
      c.qiYieldEarth=5.0; c.siteClass=SiteClass::MortalSurface;
      c.source="[原著定点] 地理研究：北原权力核心，与长生天相连；"
               "承担长生天的灾劫排遣功能，赢得王庭之争的部族可入内避灾"; add(c); }

    // ---------------- 龙鲸乐土（东海关联，交易型洞天）----------------
    { CaveParadise c; c.siteId="dh_longjing_letu"; c.name="龙鲸乐土";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::DongHai; c.region="东海关联·龙鲸乐土";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldEarth=4.0;
      c.siteClass=SiteClass::CaveInterior;
      c.source="[原著定点] 地理研究：苍蓝龙鲸关联洞天／交易空间，跨域交易网络节点"; add(c); }

    //
    //  狐仙福地 —— 【位置已依原著更正】
    //
    //  原标南疆，误。原著明载天梯山「位居中洲正中央，是传承之地，
    //  圣贤之山，古时更是仙凡之梯，可以上达天庭」，高达百万丈。
    //  方正于荡魂山攀登、仙鹤门弟子在天梯山山脚等候、
    //  方源在山顶夺得传承 —— 狐仙福地即在天梯山。
    //
    //  后有变迁：方源夺得后持有，第六卷中已将之迁入自身仙窍。
    //
    //  siteId 保留 nj_ 前缀（多处引用），但 domain 已改为中洲 ——
    //  前缀是历史遗留，注释在此说明，不误导。
    //
    { CaveParadise c; c.siteId="nj_huxian_fudi"; c.name="狐仙福地";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::ZhongZhou; c.region="中洲天梯山·狐仙福地";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldEarth=3.0;
      c.siteClass=SiteClass::CaveInterior;
      c.source="[原著定点] 天梯山位居中洲正中央，狐仙福地在天梯山；"
               "后被方源迁入自身仙窍（siteId 前缀 nj_ 为历史遗留）"; add(c); }

    { CaveParadise c; c.siteId="nj_baixiang"; c.name="白相洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::NanJiang; c.region="南疆高空·白相洞天";
      c.owner=CaveOwnership::Unclaimed; c.qiYieldHeaven=4.0;
      c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：白相洞天在南疆高空 —— "
               "说明南疆上空并非只有山峰，也有通向两天与仙窍的垂直通道"; add(c); }

    { CaveParadise c; c.siteId="nj_xiacha"; c.name="夏槎洞天";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::WhiteHeaven;
      c.domain=Domain::NanJiang; c.region="南疆·夏槎洞天";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="夏家";
      c.qiYieldHeaven=4.0; c.siteClass=SiteClass::TwoHeavens;
      c.source="[原著定点] 地理研究：属南疆宙道蛊仙的洞天"; add(c); }

    // ---------------- 盗天魔尊传承窟：玩家出生点附近 ----------------
    //
    //  原著：疯魔窟第九层藏有盗天真传（地理研究 A 级）。
    //  本作按「盗天魔尊留有传承」推演，于玩家出生地一带另设一处，
    //  使开局即可触及 —— 此为【工程设定】，非原著明载坐标，故标注清楚。
    { CaveParadise c; c.siteId="nj_daotian_chuancheng"; c.name="盗天传承窟（百家寨外）";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::NanJiang; c.region="南疆百家寨外，出生地附近的古修窟穴";
      c.owner=CaveOwnership::Unclaimed;
      c.hasEarthSpirit=false; c.qiYieldHeaven=1.0; c.qiYieldEarth=2.0;
      c.source="[工程设定] 依「疯魔窟第九层藏盗天真传」推演，于出生点附近设一处传承窟"; add(c); }

    // ---------------- 地沟：原著实有，五域皆有 ----------------
    //
    //  【已更正】此前把地沟当成「宿命蛊与监天塔崩溃后地脉翻涌」的产物，
    //  属 B 级推演 —— 这是错的。原著第 283 节「终入地沟」明写：
    //    「并不是北原才有地沟，事实上，五域都存在着地沟。」
    //    「大地裂开沟壑，有的地沟绵延千万里，有的深达数百万丈，深不见底，
    //      乃是蛊师世界中最为雄伟壮观的自然奇观之一。」
    //  且第 4524 节明写「地沟是天然形成的」—— 帝君城那道地沟是
    //  五域地脉融合导致的【新】地沟蔓延，是特定事件，不是地沟的普遍成因。
    //
    //  地沟为「十地」之一（乐土真传），可承担地脉节点。
    //  资源：盛产黑油（食道仙材，僵盟最主要经营项目）。

    // 北原僵盟地沟：阴流巨城为霸占此处资源点而建，僵盟严格把关
    { CaveParadise c; c.siteId="by_jiangmeng_digou"; c.name="北原僵盟地沟";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::BeiYuan; c.region="北原僵盟把持的地沟，阴流巨城即为此而建";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="僵盟";
      c.hasEarthSpirit=false; c.qiYieldEarth=4.0;
      c.source="原著 283 节：阴流巨城建造于此，为霸占地沟这条丰富的资源点；"
               "僵盟只能控制距地表最近的五万丈"; add(c); }

    // 中洲安祖地沟：驱邪派掌控，超级势力，三位蛊仙坐镇
    { CaveParadise c; c.siteId="cn_anzu_digou"; c.name="中洲安祖地沟（驱邪派）";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::ZhongZhou; c.region="中洲驱邪派掌控的地沟，势力范围绵延数百万里";
      c.owner=CaveOwnership::NpcFaction; c.ownerTag="驱邪派";
      c.hasEarthSpirit=false; c.qiYieldEarth=4.0;
      c.source="原著 189 节：中洲安祖地沟，驱邪派，超级势力，高层三位蛊仙坐镇"; add(c); }

    // 东海海底地沟：盛产黑油，龙鲸乐土采油任务所在
    { CaveParadise c; c.siteId="dh_haidi_digou"; c.name="东海海底地沟";
      c.kind=CaveKind::RenownedParadise; c.layer=RealmLayer::MortalSurface;
      c.domain=Domain::DongHai; c.region="东海海底的地沟，盛产黑油，向外溢出";
      c.owner=CaveOwnership::Unclaimed;
      c.hasEarthSpirit=false; c.qiYieldEarth=2.0;
      c.source="原著 878 节：方源接取任务至海岛附近海中采集地沟黑油"; add(c); }


    return t;
}

// ---------------------------------------------------------------------------
//  随机散落生成：仅太古七天碎片、幽天魔渊洞天允许随机生成
//  散落范围：五域地表 / 五域地下 / 黑天 / 白天 全域
// ---------------------------------------------------------------------------
std::vector<CaveParadise> generate_random_caves(Rng& rng, int count,
                                                const std::string& prefix) {
    static const std::vector<RealmLayer> kLayers = {
        RealmLayer::MortalSurface, RealmLayer::MortalUnderground,
        RealmLayer::BlackHeaven,   RealmLayer::WhiteHeaven
    };
    static const std::vector<Domain> kDomains = {
        Domain::ZhongZhou, Domain::BeiYuan, Domain::NanJiang,
        Domain::DongHai,   Domain::XiMo,    Domain::None
    };
    std::vector<CaveParadise> out;
    for (int i = 0; i < count; ++i) {
        CaveParadise c;
        bool fragment = rng.chance(0.65);
        c.siteId = prefix + "_" + std::to_string(i);
        c.kind   = fragment ? CaveKind::TaiguSevenFragment : CaveKind::YouTianMoyuan;
        c.name   = fragment ? ("太古七天碎片·" + std::to_string(i))
                            : ("幽天魔渊洞天·" + std::to_string(i));
        c.layer  = rng.pick(kLayers);
        c.domain = isHeavenLayer(c.layer) ? Domain::None : rng.pick(kDomains);
        c.region = std::string(to_string(c.layer)) + "·随机落点" + std::to_string(i);
        c.owner  = CaveOwnership::Unclaimed;
        c.fixedInstance = false;
        c.qiYieldHeaven = rng.range(1.0, 7.0);
        c.qiYieldEarth  = rng.range(0.5, 5.0);
        c.qiYieldHuman  = rng.range(0.0, 3.0);
        c.tribulationTimer = static_cast<int>(rng.rangeInt(20, 120));  // 万劫倒计时
        out.push_back(std::move(c));
    }
    return out;
}

} // namespace gr
