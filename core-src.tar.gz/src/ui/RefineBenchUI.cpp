// 炼蛊台界面实现（需求 8）
#include "gr/ui/ImGuiApp.hpp"
#include "gr/gu/RefineBench.hpp"
#include "gr/gu/Refining.hpp"
#include "gr/cultivator/Cultivator.hpp"

#include "imgui.h"

#include <algorithm>
#include <string>
#include <vector>

namespace gr {
namespace gui {

// ============================================================================
//  炼蛊台界面（需求 8）
//
//  流程：
//    ① 点「炼蛊」 → RefineOpen → Preparing：人物原地等待 2 秒（真实时间）
//    ② 满 2 秒 → Setup：切到地图界面，覆盖半透明灰层（透明度可在设置里调）
//    ③ Setup 三区：原材料 / 手法 / 确定·取消
//    ④ 起炉 → Refining：第三区换成 剩余时间 / 终止炼蛊 / 一心多用
//
//  覆盖层用半透明窗口实现：背景色 alpha 即「半透明灰」的强度，
//  由 DisplaySettings 提供，设置—显示设置里可调。
// ============================================================================

namespace {

// 稳定态 / 不稳定态：终止键颜色须有别（需求）
ImVec4 terminateColor(bool stable) {
    return stable ? ImVec4(0.85f, 0.62f, 0.25f, 1.0f)    // 稳定：琥珀，出半成品
                  : ImVec4(0.85f, 0.30f, 0.30f, 1.0f);   // 不稳：赤红，会失败
}

} // namespace

void App::drawRefineBench() {
    auto& bench = session_->bench();
    if (!bench.isOpen()) return;
    const RefineSession* rs = bench.cur();
    if (!rs) return;

    // ———— ① 准备阶段：人物原地等待，此时不切地图、不盖灰层 ————
    if (rs->stage == RefineStage::Preparing) {
        // 候炉提示也居中于主区，而非整屏
        const float cx = mainX_ + (mainW_ > 0 ? mainW_ : dispW_) * 0.5f - 150.0f;
        const float cy = mainY_ + (mainH_ > 0 ? mainH_ : dispH_) * 0.5f - 40.0f;
        ImGui::SetNextWindowPos(ImVec2(cx, cy));
        ImGui::SetNextWindowSize(ImVec2(300, 80));
        ImGui::SetNextWindowFocus();
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
        ImGui::Begin("##refinewait", nullptr,
                     ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                     ImGuiWindowFlags_AlwaysAutoResize);
        ImGui::Text("整备炉火……");
        ImGui::TextDisabled("%s 原地候炉（%.1f 秒）",
                            session_->playerView().name.c_str(), rs->waitRemaining);
        ImGui::ProgressBar(1.0f - rs->waitRemaining / 2.0f, ImVec2(-1, 0), "");
        ImGui::End();
        ImGui::PopStyleVar();
        return;
    }

    // ———— ②③④ 覆盖层（Setup / Refining / Finished）————
    const float alpha = std::clamp(session_->display().refineOverlayAlpha, 0.0f, 1.0f);
    // 只覆盖【中间主区（世界舆图）】—— 左侧面板、底部图例不受遮挡
    ImGui::SetNextWindowPos(ImVec2(mainX_, mainY_));
    ImGui::SetNextWindowSize(ImVec2(mainW_, mainH_));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.055f, 0.065f, 0.085f, alpha));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.35f, 0.40f, 0.50f, alpha));
    //
    //  必须把边框宽度设为 0。
    //  ImGui 窗口默认带 1px 边框，画在矩形内侧四边；
    //  覆盖层本该与主区【无缝贴合】，多出的这圈线就会显成两道横贯的线
    //  （实测左沿 x=321 是 (14,17,22)，比覆盖层内部 (16,19,25) 还暗，
    //    上下沿则是更亮的 (68,79,99) —— 与半透明灰层不同色，很扎眼）。
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14.0f, 12.0f));

    //  必须显式置焦点，把本窗口提到显示最前。
    //  ImGui 依【焦点顺序】决定绘制次序，新 Begin 的窗口默认排在最前渲染 ——
    //  也就是最底层。实测炼蛊台的 draw list 落在 CmdLists[0]，
    //  随即被主窗口、面板、地图、图例逐一覆盖，一帧下来完全看不见。
    //  （诊断时表现为：Begin 成功、draw list 有 1551 个索引，
    //    画面却与原图逐像素相同。）
    ImGui::SetNextWindowFocus();
    ImGui::Begin("##refinebench", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse);

    // 顶部：炉号切换（一心多用时可来回切看各炉）
    ImGui::Text("炼蛊台");
    ImGui::SameLine();
    if (bench.slotCount() > 1) {
        for (int i = 0; i < bench.slotCount(); ++i) {
            ImGui::SameLine();
            const bool on = (i == bench.curSlot());
            ImGui::PushID(i);
            if (ImGui::Button(on ? "*" : "o", ImVec2(24, 0)))
                bench.setCurSlot(i);
            ImGui::PopID();
            ImGui::SameLine();
            ImGui::TextDisabled("第%d炉", i + 1);
        }
        ImGui::SameLine();
        ImGui::TextDisabled("（* 当前；可切换查看）");
    }
    ImGui::SameLine(mainW_ - 120.0f);
    if (ImGui::Button("收起", ImVec2(110, 0))) queue(CmdKind::RefineClose);
    ImGui::Separator();

    drawRefineMaterials();
    ImGui::Separator();
    drawRefineTechnique();
    ImGui::Separator();
    drawRefineActions();

    ImGui::End();
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(2);

    // 背包弹窗：选原材料 / 按方自动取料
    if (refineBagOpen_) drawRefineBag();
}

// ---------------------------------------------------------------------------
//  第一部分（最上）：原材料
// ---------------------------------------------------------------------------
void App::drawRefineMaterials() {
    auto& bench = session_->bench();
    RefineSession* rs = bench.cur();
    if (!rs) return;
    const bool locked = rs->running();   // 起炉后不可再改料

    ImGui::Text("一、原材料");
    ImGui::SameLine();
    ImGui::TextDisabled("（点击一次选中，再点一次放弃）");

    ImGui::BeginDisabled(locked);
    if (ImGui::Button("选择原材料", ImVec2(150, 0))) refineBagOpen_ = true;
    ImGui::EndDisabled();
    ImGui::SameLine();
    ImGui::TextDisabled("已投入 %zu 件", rs->materialInst.size());

    // 已投入清单
    if (!rs->materialInst.empty()) {
        auto tpls = session_->world().refinery().templates();
        const Cultivator* pv = session_->world().player();
        for (GuId id : rs->materialInst) {
            std::string nm = "（未知）";
            // id 为实例 id：先查实例得模板，再得名
            if (pv) for (const auto& g : pv->carriedGu)
                if (g.instanceId == id)
                    for (const auto& t : tpls) if (t.id == g.templateId) nm = t.name;
            ImGui::BulletText("%s", nm.c_str());
            ImGui::SameLine();
            ImGui::PushID(static_cast<int>(id));
            if (!locked && ImGui::SmallButton("取回")) {
                Command c; c.kind = CmdKind::RefinePick; c.refineMat = id;
                queue(c);
            }
            ImGui::PopID();
        }
    } else {
        ImGui::TextDisabled("尚未投入任何材料");
    }

    // 需求：材料是某蛊方的一部分 —— 列出本方所需，供对照
    const GuRecipe* rp = nullptr;
    for (const GuRecipe* r : session_->world().refinery().recipes())
        if (r->id == rs->recipeId) { rp = r; break; }
    if (rp) {
        ImGui::Spacing();
        ImGui::TextDisabled("本方所需：%s（%s）", rp->name.c_str(),
                            to_string(rp->integrity));
        if (!rp->componentGu.empty()) {
            auto tpls = session_->world().refinery().templates();
            for (GuId need : rp->componentGu) {
                std::string nm = "？";
                for (const auto& t : tpls) if (t.id == need) nm = t.name;
                // 已选实例 → 模板，再看是否含此模板
                bool has = false;
                const Cultivator* pv2 = session_->world().player();
                if (pv2) for (GuId id : rs->materialInst)
                    for (const auto& g : pv2->carriedGu)
                        if (g.instanceId == id && g.templateId == need) has = true;
                ImGui::TextColored(has ? ImVec4(0.4f,0.9f,0.5f,1.0f)
                                       : ImVec4(0.85f,0.5f,0.4f,1.0f),
                                   "  %s %s", has ? "[有]" : "[缺]", nm.c_str());
            }
        }
    }
}

// ---------------------------------------------------------------------------
//  第二部分（正中）：手法选择 + 炼制进度
// ---------------------------------------------------------------------------
void App::drawRefineTechnique() {
    auto& bench = session_->bench();
    RefineSession* rs = bench.cur();
    if (!rs) return;
    const Cultivator* p = session_->world().player();

    ImGui::Text("二、炼蛊手法");
    ImGui::SameLine();
    ImGui::TextDisabled("（默认「无」：直接炼制不需特殊手法）");

    const bool locked = rs->running();
    const int curId = rs->techniqueId;
    const RefineTechnique* curTech = refineTechnique(curId);

    ImGui::BeginDisabled(locked);
    // 下拉：点箭头展开，点击选择，滚轮上下滚动
    if (ImGui::Button(curTech ? curTech->name.c_str() : "无", ImVec2(180, 0)))
        techComboOpen_ = !techComboOpen_;
    ImGui::SameLine();
    if (ImGui::ArrowButton("##techarrow",
                           techComboOpen_ ? ImGuiDir_Down : ImGuiDir_Right))
        techComboOpen_ = !techComboOpen_;
    ImGui::EndDisabled();

    if (techComboOpen_ && !locked) {
        ImGui::BeginChild("##techlist", ImVec2(280, 150), true);
        // 需求：列表中所有手法均为【玩家已学过】的手法
        const auto& all = allRefineTechniques();
        // 只取已学
        std::vector<const RefineTechnique*> known;
        for (const auto& t : all)
            if (!p || p->knowsTechnique(t.id)) known.push_back(&t);

        // 滚轮滚动
        if (ImGui::IsWindowHovered()) {
            const float w = ImGui::GetIO().MouseWheel;
            if (w != 0.0f && !known.empty()) {
                techHover_ = std::clamp(techHover_ + (w > 0 ? -1 : 1),
                                        0, static_cast<int>(known.size()) - 1);
            }
        }
        for (int i = 0; i < static_cast<int>(known.size()); ++i) {
            const RefineTechnique* t = known[i];
            const bool sel = (t->id == curId);
            const bool hov = (i == techHover_);
            if (hov || sel) {
                ImGui::PushStyleColor(ImGuiCol_Text,
                    sel ? ImVec4(0.4f, 0.95f, 0.55f, 1.0f)
                        : ImVec4(1.0f, 0.9f, 0.5f, 1.0f));
            }
            if (ImGui::Selectable(t->name.c_str(), sel)) {
                Command c; c.kind = CmdKind::RefineTechnique; c.refineTech = t->id;
                queue(c);
                techComboOpen_ = false;
            }
            if (hov || sel) ImGui::PopStyleColor();
            if (ImGui::IsItemHovered()) {
                techHover_ = i;
                ImGui::SetTooltip("%s\n%s", t->name.c_str(), t->desc.c_str());
            }
        }
        if (known.size() == 1)
            ImGui::TextDisabled("（仅「无」一种：尚未习得其他手法，"
                                "可读书或拜师以学）");
        ImGui::EndChild();
    }

    if (curTech && curTech->id != 0)
        ImGui::TextDisabled("%s", curTech->desc.c_str());

    // —— 进度条 ——
    ImGui::Spacing();
    if (rs->stage == RefineStage::Refining || rs->stage == RefineStage::Finished) {
        ImGui::Text("炼制进度");
        ImGui::SameLine();
        ImGui::ProgressBar(rs->progress(), ImVec2(-1, 0));
        ImGui::TextDisabled("剩余 %lld 刻（世界时间）"
                            "　已炼 %lld 刻　冷却 %lld 刻",
                            (long long)rs->remainTicks, (long long)rs->elapsed(),
                            (long long)rs->cooldownTicks);
        if (rs->timeGuUsed) ImGui::TextColored(
            ImVec4(0.5f, 0.85f, 1.0f, 1.0f), "光阴蛊已投入：流速 ×%.1f", rs->speedMul);
    } else {
        ImGui::TextDisabled("尚未起炉");
    }
}

// ---------------------------------------------------------------------------
//  第三部分（最下）：确定·取消 / 剩余时间·终止·一心多用
// ---------------------------------------------------------------------------
void App::drawRefineActions() {
    auto& bench = session_->bench();
    RefineSession* rs = bench.cur();
    if (!rs) return;
    const Cultivator* p = session_->world().player();

    ImGui::Text("三、起炉");

    if (rs->stage == RefineStage::Setup) {
        // —— 未起炉：确定 / 取消 ——
        if (ImGui::Button("确定（开始炼蛊）", ImVec2(180, 0))) {
            Command c; c.kind = CmdKind::RefineBegin; queue(c);
        }
        ImGui::SameLine();
        if (ImGui::Button("取消", ImVec2(100, 0))) {
            Command c; c.kind = CmdKind::RefineCancel; queue(c);
        }
        return;
    }

    // —— 起炉后：确定/取消隐藏，换成剩余时间 / 终止 / 一心多用 ——
    if (rs->stage == RefineStage::Refining) {
        // 剩余时间（世界时间）
        ImGui::Text("剩余时间：%lld 刻", (long long)rs->remainTicks);
        ImGui::SameLine();

        // 终止炼蛊：稳定态与不稳定态颜色不同
        ImGui::PushStyleColor(ImGuiCol_Button, terminateColor(rs->stable));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, terminateColor(rs->stable));
        const bool canTerm = rs->canTerminate();
        ImGui::BeginDisabled(!canTerm);
        if (ImGui::Button("终止炼蛊", ImVec2(120, 0))) {
            Command c; c.kind = CmdKind::RefineTerminate; queue(c);
        }
        ImGui::EndDisabled();
        ImGui::PopStyleColor(2);
        if (ImGui::IsItemHovered()) {
            if (!canTerm)
                ImGui::SetTooltip("起炉未稳：已炼 %lld 刻 < 冷却 %lld 刻，不可撤手",
                                  (long long)rs->elapsed(), (long long)rs->cooldownTicks);
            else if (rs->stable)
                ImGui::SetTooltip("炉火平稳 —— 此时收炉可得半成品");
            else
                ImGui::SetTooltip("炉火不稳 —— 此时收炉会炼蛊失败");
        }

        ImGui::SameLine();
        // 一心多用：魂魄不足须借「一心多用」系列蛊，否则不可点
        const bool hasMulti = session_->hasMultiTaskGu();
        const bool canMulti = RefineBench::canMultiTask(
            p ? p->soulStrength : 0, bench.slotCount(), hasMulti);
        ImGui::BeginDisabled(!canMulti);
        if (ImGui::Button("一心多用", ImVec2(120, 0))) {
            // 再开一炉：沿用当前蛊方
            Command c; c.kind = CmdKind::RefineMulti;
            c.refineRecipe = rs->recipeId;
            queue(c);
        }
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered()) {
            if (canMulti)
                ImGui::SetTooltip("再起一炉（魂魄 %d）；炉间可用顶部第N炉切换",
                                  p ? p->soulStrength : 0);
            else
                ImGui::SetTooltip("魂魄强度不足（%d），须借「一心多用」系列蛊"
                                  "（一心二用蛊、一心三用蛊……）",
                                  p ? p->soulStrength : 0);
        }

        ImGui::SameLine();
        // 光阴蛊加速
        const bool hasTime = session_->hasTimeGu();
        ImGui::BeginDisabled(!hasTime || rs->timeGuUsed);
        if (ImGui::Button("光阴蛊加速", ImVec2(120, 0))) {
            Command c; c.kind = CmdKind::RefineTimeGu; queue(c);
        }
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered()) {
            if (!hasTime) ImGui::SetTooltip("囊中无光阴蛊");
            else if (rs->timeGuUsed) ImGui::SetTooltip("此炉已用过光阴蛊");
            else ImGui::SetTooltip("投入光阴蛊：炼制流速加倍");
        }
        ImGui::TextDisabled("提示：推进世界即可推进炼制（剩余时间以世界时间计）");
        return;
    }

    if (rs->stage == RefineStage::Finished) {
        // 完成：蛊已自动归入囊中，界面待收起
        ImGui::TextColored(rs->outcome == RefineOutcome::Failure
                               ? ImVec4(0.9f, 0.45f, 0.45f, 1.0f)
                               : ImVec4(0.45f, 0.92f, 0.55f, 1.0f),
                           "本炉结果：%s", to_string(rs->outcome));
        if (!rs->productName.empty())
            ImGui::Text("所得：%s（已归入囊中）", rs->productName.c_str());
        if (!rs->detail.empty()) ImGui::TextDisabled("%s", rs->detail.c_str());
        if (ImGui::Button("收起", ImVec2(120, 0))) queue(CmdKind::RefineClose);
    }
}

// ---------------------------------------------------------------------------
//  背包弹窗：选材料 / 按蛊方自动取料
// ---------------------------------------------------------------------------
void App::drawRefineBag() {
    auto& bench = session_->bench();
    const int slot = bench.curSlot();
    const Cultivator* p = session_->world().player();
    if (!p) { refineBagOpen_ = false; return; }

    ImGui::SetNextWindowSize(ImVec2(560, 460), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("选择原材料", &refineBagOpen_)) { ImGui::End(); return; }

    if (ImGui::BeginTabBar("bagTabs")) {
        // —— 囊中蛊：点一次选中，两次放弃 ——
        if (ImGui::BeginTabItem("囊中蛊")) {
            if (p->carriedGu.empty()) {
                ImGui::TextDisabled("囊中空空。");
            } else {
                auto tpls = session_->world().refinery().templates();
                for (const auto& inst : p->carriedGu) {
                    std::string nm = "？";
                    Rank rk = Rank::R1;
                    for (const auto& t : tpls)
                        if (t.id == inst.templateId) { nm = t.name; rk = t.rank; }
                    const bool picked = bench.hasMaterial(slot, inst.instanceId);
                    // 已选中者高亮，再点即放弃
                    if (picked) {
                        ImGui::PushStyleColor(ImGuiCol_Text,
                                              ImVec4(0.4f, 0.95f, 0.55f, 1.0f));
                    }
                    ImGui::PushID(static_cast<int>(inst.instanceId));
                    if (ImGui::Selectable(nm.c_str(), picked)) {
                        Command c; c.kind = CmdKind::RefinePick;
                        c.refineMat = inst.instanceId; c.refineSlot = slot;
                        queue(c);
                    }
                    ImGui::PopID();
                    if (picked) ImGui::PopStyleColor();
                    ImGui::SameLine();
                    ImGui::TextDisabled("%s　%s", to_string(rk),
                                        picked ? "已投入（再点取回）" : "点击投入");
                }
            }
            ImGui::EndTabItem();
        }

        // —— 蛊方：只显示蛊虫名称，悬浮看详情，点击自动取料 ——
        if (ImGui::BeginTabItem("按方取料")) {
            ImGui::TextDisabled("鼠标停在蛊方名上看组成蛊虫；点击自动取出囊中相应蛊材");
            auto recipes = session_->world().refinery().recipes();
            auto tpls    = session_->world().refinery().templates();
            for (const GuRecipe* r : recipes) {
                // 需求：一部分的蛊方中只显示蛊虫名称
                ImGui::PushID(static_cast<int>(r->id));
                // 折叠树节点：蛊方多时可收起
                const bool open = ImGui::TreeNode(r->name.c_str());
                // 悬浮显示详细内容（什么蛊虫）
                if (ImGui::IsItemHovered()) {
                    ImGui::BeginTooltip();
                    ImGui::Text("%s（%s / %s）", r->name.c_str(),
                                to_string(r->targetRank), to_string(r->dao));
                    ImGui::Separator();
                    if (r->componentGu.empty()) {
                        ImGui::TextDisabled("组成：不详（资料库未收录）");
                    } else {
                        ImGui::Text("组成蛊虫：");
                        for (GuId g : r->componentGu) {
                            std::string nm = "？";
                            for (const auto& t : tpls) if (t.id == g) nm = t.name;
                            ImGui::BulletText("%s", nm.c_str());
                        }
                    }
                    ImGui::EndTooltip();
                }
                if (open) {
                    // 点击自动取出相应蛊材
                    if (ImGui::SmallButton("自动取料")) {
                        // 逐个所需模板，在囊中找一只【尚未投入】的同种蛊。
                        //  取实例而非模板：方子要两只同种蛊时才分得开。
                        for (GuId g : r->componentGu) {
                            for (const auto& inst : p->carriedGu) {
                                if (inst.templateId != g) continue;
                                if (bench.hasMaterial(slot, inst.instanceId)) continue;
                                Command c; c.kind = CmdKind::RefinePick;
                                c.refineMat = inst.instanceId; c.refineSlot = slot;
                                queue(c);
                                break;   // 本轮只取一只，多只需再点
                            }
                        }
                    }
                    ImGui::TreePop();
                }
                ImGui::PopID();
            }
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}

// ---------------------------------------------------------------------------
//  设置 — 显示设置
// ---------------------------------------------------------------------------
void App::drawSettingsWindow() {
    ImGui::SetNextWindowSize(ImVec2(380, 240), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("设置", &settingsOpen_)) { ImGui::End(); return; }
    if (ImGui::BeginTabBar("setTabs")) {
        if (ImGui::BeginTabItem("显示设置")) {
            ImGui::Text("炼蛊覆盖层");
            ImGui::TextDisabled("炼蛊时覆盖于地图之上的灰色层不透明度");
            ImGui::SliderFloat("不透明度##overlay",
                               &session_->display().refineOverlayAlpha, 0.0f, 1.0f,
                               "%.2f");
            ImGui::TextDisabled("0 = 全透明（不遮挡地图）　1 = 完全不透明");
            // 预览
            ImGui::Spacing();
            ImGui::TextDisabled("预览：");
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_ChildBg,
                ImVec4(0.055f, 0.065f, 0.085f,
                       session_->display().refineOverlayAlpha));
            ImGui::BeginChild("##prev", ImVec2(160, 40), true);
            ImGui::TextColored(ImVec4(0.8f, 0.85f, 0.95f, 1.0f), "炼蛊台覆盖层");
            ImGui::EndChild();
            ImGui::PopStyleColor();
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
    // —— 地形图（细化）——
    ImGui::Separator();
    ImGui::Text("地形图");
    ImGui::Checkbox("山体阴影", &showHillshade_);
    ImGui::SameLine();
    ImGui::TextDisabled("依坡度算明暗，显出山脊与沟谷走向");
    ImGui::Checkbox("等高线", &showContour_);
    ImGui::SameLine();
    ImGui::TextDisabled("每 12 级高程一条，放大后可见");
}


// ===========================================================================
//  背包页签（需求 12）
//
//  两栏并列：
//    左＝囊中蛊（活的、有唯一性与状态，存 Cultivator::carriedGu）
//    右＝物品（材料、消耗品、天材地宝等死物，存 Inventory）
//  分开陈列是因为二者性质不同：蛊有转数与完损，物品只有数量。
// ===========================================================================
void App::drawBagTab() {
    const Cultivator* p = session_->player();
    if (!p) { ImGui::TextWrapped("尚未创建角色。"); return; }

    // —— 概要 ——
    ImGui::Text("囊中蛊 %zu 只　物品 %zu 种", p->carriedGu.size(), p->bag.size());
    ImGui::SameLine();
    ImGui::TextDisabled("（总件数约 %.0f）", p->bag.totalWeight());
    ImGui::Separator();

    // ---------------------------------------------------------------- 左：蛊
    //  两栏各占一半。
    //  若都用 ImVec2(-1,0)（填满剩余宽度），第二栏会被挤到画面外 ——
    //  实测整片区域只剩背景色，什么都看不见。
    const float colW = (mainW_ > 40.0f ? mainW_ : dispW_) * 0.5f - 14.0f;
    const float colH = (mainH_ > 40.0f ? mainH_ : dispH_) - 60.0f;

    ImGui::BeginChild("##baggu", ImVec2(colW, colH), false);
    ImGui::Text("囊中蛊");
    ImGui::Separator();
    if (p->carriedGu.empty()) {
        ImGui::TextDisabled("囊中无蛊。");
    } else {
        auto tpls = session_->world().refinery().templates();
        // 表格须显式声明列尺寸策略，否则 ImGui 断言失败
        if (ImGui::BeginTable("guTable", 4,
                              ImGuiTableFlags_RowBg | ImGuiTableFlags_Borders |
                              ImGuiTableFlags_ScrollY, ImVec2(-1, 0))) {
            ImGui::TableSetupColumn("蛊名", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableSetupColumn("转数", ImGuiTableColumnFlags_WidthFixed, 60);
            ImGui::TableSetupColumn("状态", ImGuiTableColumnFlags_WidthFixed, 70);
            ImGui::TableSetupColumn("完整", ImGuiTableColumnFlags_WidthFixed, 70);
            ImGui::TableHeadersRow();
            for (const auto& inst : p->carriedGu) {
                std::string nm = "？"; Rank rk = Rank::R1; std::string eff;
                for (const auto& t : tpls)
                    if (t.id == inst.templateId) { nm = t.name; rk = t.rank; eff = t.effect; }
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0);
                ImGui::Text("%s%s", nm.c_str(), inst.defective ? "（残）" : "");
                if (ImGui::IsItemHovered() && !eff.empty())
                    ImGui::SetTooltip("%s", eff.c_str());
                ImGui::TableSetColumnIndex(1);
                ImGui::Text("%s", to_string(rk));
                ImGui::TableSetColumnIndex(2);
                ImGui::Text("%s", to_string(inst.state));
                ImGui::TableSetColumnIndex(3);
                ImGui::Text("%.0f%%", inst.integrity * 100.0);
            }
            ImGui::EndTable();
        }
    }
    ImGui::EndChild();

    // 两栏并排：必须 SameLine，否则右栏会换行到左栏下方而不可见
    ImGui::SameLine();
    // 分隔线（ImGui 无现成的竖直分隔 API，取窗口绘制列表手绘）
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 sep = ImGui::GetCursorScreenPos();
        dl->AddLine(ImVec2(sep.x - 4, sep.y), ImVec2(sep.x - 4, sep.y + colH),
                    IM_COL32(70, 80, 100, 255), 1.0f);
    }

    // ---------------------------------------------------------------- 右：物品
    ImGui::BeginChild("##bagitem", ImVec2(colW, colH), false);
    ImGui::Text("物品");
    ImGui::SameLine();
    if (ImGui::Button("就地采集", ImVec2(90, 0))) queue(CmdKind::BagGather);
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("于当前地形采获材料：山川得痕石，灵脉得灵石，草木得止血草");
    ImGui::Separator();

    auto items = session_->bagItems();
    if (items.empty()) {
        ImGui::TextDisabled("身无长物。");
    } else {
        if (ImGui::BeginTable("itemTable", 3,
                              ImGuiTableFlags_RowBg | ImGuiTableFlags_Borders |
                              ImGuiTableFlags_ScrollY, ImVec2(-1, 0))) {
            ImGui::TableSetupColumn("物品", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableSetupColumn("数量", ImGuiTableColumnFlags_WidthFixed, 60);
            ImGui::TableSetupColumn("操作", ImGuiTableColumnFlags_WidthFixed, 90);
            ImGui::TableHeadersRow();
            ItemKind lastKind = ItemKind::Treasure;
            bool firstRow = true;
            for (const ItemStack* it : items) {
                // 分类分组表头
                if (firstRow || it->kind != lastKind) {
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::TextColored(ImVec4(0.55f, 0.75f, 0.95f, 1.0f),
                                       "— %s —", to_string(it->kind));
                    lastKind = it->kind; firstRow = false;
                }
                ImGui::PushID(it->name.c_str());
                ImGui::TableNextRow();
                ImGui::TableSetColumnIndex(0);
                ImGui::Text("%s", it->name.c_str());
                // 悬浮：用途与溯源
                if (ImGui::IsItemHovered()) {
                    ImGui::BeginTooltip();
                    ImGui::Text("%s（%s）", it->name.c_str(), to_string(it->kind));
                    if (!it->desc.empty()) ImGui::TextWrapped("%s", it->desc.c_str());
                    if (!it->source.empty()) {
                        ImGui::Separator();
                        ImGui::TextDisabled("溯源：%s", it->source.c_str());
                    }
                    // 该材料用于哪些蛊方 —— 让玩家知道为何要留着
                    std::string usedBy;
                    for (const GuRecipe* r : session_->world().refinery().recipes()) {
                        if (!r) continue;
                        for (const auto& m : r->materials)
                            if (m.name == it->name) { usedBy += r->name + "、"; break; }
                    }
                    if (!usedBy.empty()) {
                        ImGui::Separator();
                        ImGui::TextWrapped("用于：%s", usedBy.c_str());
                    }
                    ImGui::EndTooltip();
                }
                ImGui::TableSetColumnIndex(1);
                ImGui::Text("%.0f", it->amount);
                ImGui::TableSetColumnIndex(2);
                // 消耗品可用，其余只可弃
                if (it->kind == ItemKind::Consumable) {
                    if (ImGui::SmallButton("使用")) {
                        Command c; c.kind = CmdKind::BagUse;
                        c.itemName = it->name; c.itemAmount = 1.0;
                        queue(c);
                    }
                    ImGui::SameLine();
                }
                if (ImGui::SmallButton("弃")) {
                    Command c; c.kind = CmdKind::BagDrop;
                    c.itemName = it->name; c.itemAmount = 1.0;
                    queue(c);
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextDisabled("说明：蛊虫与物品分栏陈列 —— 蛊为活物，有转数、状态与完损；"
                        "物品为死物，只计数量。");
    ImGui::TextDisabled("材料不足时炼蛊会被拦下并指明所缺，可先就地采集或入秘境寻获。");
    ImGui::EndChild();
}

} // namespace gui
} // namespace gr
