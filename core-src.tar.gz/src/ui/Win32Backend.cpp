// Win32 + GDI 软件后端实现（见头文件说明）
//
// 本文件整体由 _WIN32 包裹：在非 Windows 平台编译时为空翻译单元，
// 因此 Linux / headless 构建完全不受影响。
#include "gr/ui/Win32Backend.hpp"

#ifdef _WIN32

#include "imgui.h"

#include <cstring>

#ifndef GET_X_LPARAM
#define GET_X_LPARAM(lp) ((int)(short)LOWORD(lp))
#define GET_Y_LPARAM(lp) ((int)(short)HIWORD(lp))
#endif

namespace gr {
namespace win32 {

namespace {

const char* const kClassName = "GuZhenRenWin32";

// Win32 虚拟键 → ImGuiKey。
// 只需覆盖本作实际用到的键（WASD/方向键、功能键、文本输入相关）。
ImGuiKey vkToImGuiKey(WPARAM vk) {
    if (vk >= 'A' && vk <= 'Z') return ImGuiKey(ImGuiKey_A + (vk - 'A'));
    if (vk >= '0' && vk <= '9') return ImGuiKey(ImGuiKey_0 + (vk - '0'));
    if (vk >= VK_F1 && vk <= VK_F12) return ImGuiKey(ImGuiKey_F1 + (vk - VK_F1));
    switch (vk) {
        case VK_LEFT:     return ImGuiKey_LeftArrow;
        case VK_RIGHT:    return ImGuiKey_RightArrow;
        case VK_UP:       return ImGuiKey_UpArrow;
        case VK_DOWN:     return ImGuiKey_DownArrow;
        case VK_TAB:      return ImGuiKey_Tab;
        case VK_RETURN:   return ImGuiKey_Enter;
        case VK_ESCAPE:   return ImGuiKey_Escape;
        case VK_BACK:     return ImGuiKey_Backspace;
        case VK_DELETE:   return ImGuiKey_Delete;
        case VK_INSERT:   return ImGuiKey_Insert;
        case VK_HOME:     return ImGuiKey_Home;
        case VK_END:      return ImGuiKey_End;
        case VK_PRIOR:    return ImGuiKey_PageUp;
        case VK_NEXT:     return ImGuiKey_PageDown;
        case VK_SPACE:    return ImGuiKey_Space;
        case VK_SHIFT:    return ImGuiKey_LeftShift;
        case VK_CONTROL:  return ImGuiKey_LeftCtrl;
        case VK_MENU:     return ImGuiKey_LeftAlt;
        case VK_LSHIFT:   return ImGuiKey_LeftShift;
        case VK_RSHIFT:   return ImGuiKey_RightShift;
        case VK_LCONTROL: return ImGuiKey_LeftCtrl;
        case VK_RCONTROL: return ImGuiKey_RightCtrl;
        case VK_LMENU:    return ImGuiKey_LeftAlt;
        case VK_RMENU:    return ImGuiKey_RightAlt;
        default:          return ImGuiKey_None;
    }
}

LRESULT CALLBACK wndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    Backend* b = reinterpret_cast<Backend*>(
        GetWindowLongPtr(hwnd, GWLP_USERDATA));
    ImGuiIO& io = ImGui::GetIO();

    switch (msg) {
        case WM_DESTROY:
            if (b) b->quit = true;
            PostQuitMessage(0);
            return 0;

        case WM_SIZE: {
            if (!b) break;
            const int w = GET_X_LPARAM(lParam), h = GET_Y_LPARAM(lParam);
            if (w > 0 && h > 0) { b->width = w; b->height = h; }
            return 0;
        }

        // —— 鼠标 ——
        case WM_MOUSEMOVE:
            io.AddMousePosEvent((float)GET_X_LPARAM(lParam),
                                (float)GET_Y_LPARAM(lParam));
            return 0;
        case WM_LBUTTONDOWN: io.AddMouseButtonEvent(0, true);  return 0;
        case WM_LBUTTONUP:   io.AddMouseButtonEvent(0, false); return 0;
        case WM_RBUTTONDOWN: io.AddMouseButtonEvent(1, true);  return 0;
        case WM_RBUTTONUP:   io.AddMouseButtonEvent(1, false); return 0;
        case WM_MBUTTONDOWN: io.AddMouseButtonEvent(2, true);  return 0;
        case WM_MBUTTONUP:   io.AddMouseButtonEvent(2, false); return 0;
        case WM_MOUSEWHEEL:
            io.AddMouseWheelEvent(0.0f,
                (float)(GET_WHEEL_DELTA_WPARAM(wParam)) / (float)WHEEL_DELTA);
            return 0;

        // —— 键盘 ——
        case WM_KEYDOWN:
        case WM_SYSKEYDOWN: {
            const ImGuiKey k = vkToImGuiKey(wParam);
            if (k != ImGuiKey_None) io.AddKeyEvent(k, true);
            // 修饰键须单独同步：否则 Ctrl+C 之类组合键判不出来
            io.AddKeyEvent(ImGuiKey_ModCtrl,  (GetKeyState(VK_CONTROL) & 0x8000) != 0);
            io.AddKeyEvent(ImGuiKey_ModShift, (GetKeyState(VK_SHIFT)   & 0x8000) != 0);
            io.AddKeyEvent(ImGuiKey_ModAlt,   (GetKeyState(VK_MENU)    & 0x8000) != 0);
            return 0;
        }
        case WM_KEYUP:
        case WM_SYSKEYUP: {
            const ImGuiKey k = vkToImGuiKey(wParam);
            if (k != ImGuiKey_None) io.AddKeyEvent(k, false);
            io.AddKeyEvent(ImGuiKey_ModCtrl,  (GetKeyState(VK_CONTROL) & 0x8000) != 0);
            io.AddKeyEvent(ImGuiKey_ModShift, (GetKeyState(VK_SHIFT)   & 0x8000) != 0);
            io.AddKeyEvent(ImGuiKey_ModAlt,   (GetKeyState(VK_MENU)    & 0x8000) != 0);
            return 0;
        }
        case WM_CHAR:
            // 文本输入：交给 ImGui，改名 / 开局取名要靠它
            if (wParam >= 0x20 && wParam != 0x7F)
                io.AddInputCharacterUTF16((ImWchar16)wParam);
            return 0;

        default: break;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

} // namespace

bool create(Backend& b, int width, int height, const char* title) {
    b.width = width; b.height = height;

    HINSTANCE hInst = GetModuleHandle(nullptr);
    WNDCLASSEX wc;
    std::memset(&wc, 0, sizeof(wc));
    wc.cbSize        = sizeof(wc);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = wndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = kClassName;
    if (!RegisterClassEx(&wc)) return false;

    // 窗口尺寸含边框，故客户区须另算
    DWORD style = WS_OVERLAPPEDWINDOW;
    RECT r = {0, 0, width, height};
    AdjustWindowRect(&r, style, FALSE);

    b.hwnd = CreateWindowEx(0, kClassName, title ? title : "蛊真人",
                            style, CW_USEDEFAULT, CW_USEDEFAULT,
                            r.right - r.left, r.bottom - r.top,
                            nullptr, nullptr, hInst, nullptr);
    if (!b.hwnd) return false;

    SetWindowLongPtr(b.hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(&b));
    b.hdc = GetDC(b.hwnd);
    ShowWindow(b.hwnd, SW_SHOW);
    UpdateWindow(b.hwnd);
    return true;
}

bool pumpEvents(Backend& b) {
    MSG msg;
    // PeekMessage 而非 GetMessage：空闲时也要继续出帧做动画（面板滑动、特效）
    while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
        if (msg.message == WM_QUIT) { b.quit = true; return false; }
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return !b.quit;
}

void present(Backend& b, const unsigned char* rgba, int w, int h) {
    if (!b.hdc || w <= 0 || h <= 0) return;

    // 尺寸变化时重建 DIB
    if (!b.dib || b.dibW != w || b.dibH != h) {
        if (b.dib) DeleteObject(b.dib);
        BITMAPINFOHEADER bih;
        std::memset(&bih, 0, sizeof(bih));
        bih.biSize        = sizeof(bih);
        bih.biWidth       = w;
        bih.biHeight      = -h;          // 负值 = top-down，省去翻转
        bih.biPlanes      = 1;
        bih.biBitCount    = 32;
        bih.biCompression = BI_RGB;
        BITMAPINFO bi;
        std::memset(&bi, 0, sizeof(bi));
        bi.bmiHeader = bih;
        b.dib = CreateDIBSection(b.hdc, &bi, DIB_RGB_COLORS, &b.dibBits, nullptr, 0);
        b.dibW = w; b.dibH = h;
        if (!b.dib) return;
    }

    // RGBA → BGRA：GDI 的 32bpp BI_RGB 按 B、G、R、X 排列
    unsigned char* dst = static_cast<unsigned char*>(b.dibBits);
    const int n = w * h;
    for (int i = 0; i < n; ++i) {
        const unsigned char* s = rgba + i * 4;
        unsigned char* d = dst + i * 4;
        d[0] = s[2];   // B
        d[1] = s[1];   // G
        d[2] = s[0];   // R
        d[3] = s[3];   // A
    }

    HDC mem = CreateCompatibleDC(b.hdc);
    if (!mem) return;
    HGDIOBJ old = SelectObject(mem, b.dib);
    StretchBlt(b.hdc, 0, 0, b.width, b.height,
               mem, 0, 0, w, h, SRCCOPY);
    SelectObject(mem, old);
    DeleteDC(mem);
}

void destroy(Backend& b) {
    if (b.dib) { DeleteObject(b.dib); b.dib = nullptr; }
    if (b.hdc && b.hwnd) { ReleaseDC(b.hwnd, b.hdc); b.hdc = nullptr; }
    if (b.hwnd) { DestroyWindow(b.hwnd); b.hwnd = nullptr; }
}

double nowSeconds() {
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER t;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)freq.QuadPart;
}

} // namespace win32
} // namespace gr

#endif // _WIN32
