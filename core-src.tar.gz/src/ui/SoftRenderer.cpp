// ImGui 软件光栅化后端实现
#include "gr/ui/SoftRenderer.hpp"

#include "imgui.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace gr {
namespace soft {

void Bitmap::clear(std::uint8_t r, std::uint8_t g, std::uint8_t b, std::uint8_t a) {
    for (std::size_t i = 0; i < pixels.size(); i += 4) {
        pixels[i + 0] = r;
        pixels[i + 1] = g;
        pixels[i + 2] = b;
        pixels[i + 3] = a;
    }
}

void Bitmap::setPixel(int x, int y, std::uint8_t r, std::uint8_t g,
                      std::uint8_t b, std::uint8_t a) {
    if (x < 0 || y < 0 || x >= width || y >= height) return;
    std::size_t o = (static_cast<std::size_t>(y) * width + x) * 4;

    if (a >= 255) {
        pixels[o + 0] = r; pixels[o + 1] = g;
        pixels[o + 2] = b; pixels[o + 3] = 255;
        return;
    }
    // 标准 alpha 混合：out = src*a + dst*(1-a)
    const float sa = a / 255.0f;
    const float da = pixels[o + 3] / 255.0f;
    const float oa = sa + da * (1.0f - sa);
    if (oa <= 0.0f) return;

    auto mix = [&](std::uint8_t s, std::uint8_t d) -> std::uint8_t {
        float v = (s * sa + d * da * (1.0f - sa)) / oa;
        return static_cast<std::uint8_t>(std::clamp(v, 0.0f, 255.0f));
    };
    pixels[o + 0] = mix(r, pixels[o + 0]);
    pixels[o + 1] = mix(g, pixels[o + 1]);
    pixels[o + 2] = mix(b, pixels[o + 2]);
    pixels[o + 3] = static_cast<std::uint8_t>(std::clamp(oa * 255.0f, 0.0f, 255.0f));
}

namespace {

// 采样字体图集（Alpha8）。越界返回 0，避免文字边缘出现杂点。
inline std::uint8_t sampleFont(const std::uint8_t* px, int w, int h,
                               float u, float v) {
    if (!px || w <= 0 || h <= 0) return 255;
    int x = static_cast<int>(u * w);
    int y = static_cast<int>(v * h);
    // 纹理坐标钳制到边缘
    x = std::clamp(x, 0, w - 1);
    y = std::clamp(y, 0, h - 1);
    return px[static_cast<std::size_t>(y) * w + x];
}

// 光栅化一个三角形（带裁剪矩形 + 顶点插值 + 纹理采样）
void rasterTriangle(Bitmap& bmp,
                    float x0, float y0, float u0, float v0, ImU32 c0,
                    float x1, float y1, float u1, float v1, ImU32 c1,
                    float x2, float y2, float u2, float v2, ImU32 c2,
                    const std::uint8_t* fontPx, int fontW, int fontH,
                    bool hasTex,
                    float clipX0, float clipY0, float clipX1, float clipY1) {
    // 包围盒
    float minX = std::max(std::min({x0, x1, x2}), clipX0);
    float maxX = std::min(std::max({x0, x1, x2}), clipX1);
    float minY = std::max(std::min({y0, y1, y2}), clipY0);
    float maxY = std::min(std::max({y0, y1, y2}), clipY1);
    if (minX > maxX || minY > maxY) return;

    const float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    if (std::abs(area) < 1e-6f) return;
    const float inv = 1.0f / area;

    // 像素中心采样，避免半像素偏移
    const int px0 = static_cast<int>(std::floor(minX));
    const int px1 = static_cast<int>(std::ceil(maxX));
    const int py0 = static_cast<int>(std::floor(minY));
    const int py1 = static_cast<int>(std::ceil(maxY));

    auto unpack = [](ImU32 c, int i) -> std::uint8_t {
        return static_cast<std::uint8_t>((c >> (i * 8)) & 0xFF);
    };

    for (int py = py0; py < py1; ++py) {
        for (int px = px0; px < px1; ++px) {
            const float cx = px + 0.5f;
            const float cy = py + 0.5f;

            // 重心坐标
            float w0 = ((x1 - cx) * (y2 - cy) - (x2 - cx) * (y1 - cy)) * inv;
            float w1 = ((x2 - cx) * (y0 - cy) - (x0 - cx) * (y2 - cy)) * inv;
            float w2 = 1.0f - w0 - w1;
            // 带容差，避免相邻三角形之间出现缝隙
            if (w0 < -0.001f || w1 < -0.001f || w2 < -0.001f) continue;

            ImU32 col;
            float u = 0.0f, v = 0.0f;
            if (hasTex) {
                u = w0 * u0 + w1 * u1 + w2 * u2;
                v = w0 * v0 + w1 * v1 + w2 * v2;
                col = c0;   // 文字用首个顶点色，alpha 由纹理决定
            } else {
                // 无纹理时插值顶点色
                std::uint8_t r = static_cast<std::uint8_t>(
                    w0 * unpack(c0, 0) + w1 * unpack(c1, 0) + w2 * unpack(c2, 0));
                std::uint8_t g = static_cast<std::uint8_t>(
                    w0 * unpack(c0, 1) + w1 * unpack(c1, 1) + w2 * unpack(c2, 1));
                std::uint8_t b = static_cast<std::uint8_t>(
                    w0 * unpack(c0, 2) + w1 * unpack(c1, 2) + w2 * unpack(c2, 2));
                std::uint8_t a = static_cast<std::uint8_t>(
                    w0 * unpack(c0, 3) + w1 * unpack(c1, 3) + w2 * unpack(c2, 3));
                col = IM_COL32(r, g, b, a);
            }

            std::uint8_t alpha = unpack(col, 3);
            if (hasTex) {
                // 字体图集为 Alpha8：最终 alpha = 顶点色 alpha × 纹素
                std::uint8_t t = sampleFont(fontPx, fontW, fontH, u, v);
                alpha = static_cast<std::uint8_t>((alpha * t) / 255);
            }
            if (alpha == 0) continue;

            bmp.setPixel(px, py, unpack(col, 0), unpack(col, 1), unpack(col, 2), alpha);
        }
    }
}

} // namespace

void renderDrawData(ImDrawData* drawData, Bitmap& bmp,
                    const std::uint8_t* fontPixels, int fontW, int fontH) {
    if (!drawData) return;

    const int fbW = static_cast<int>(drawData->DisplaySize.x);
    const int fbH = static_cast<int>(drawData->DisplaySize.y);
    if (fbW <= 0 || fbH <= 0) return;
    bmp.resize(fbW, fbH);
    bmp.clear(24, 26, 32, 255);   // 深色底，贴近常见 ImGui 配色

    for (int n = 0; n < drawData->CmdListsCount; ++n) {
        const ImDrawList* list = drawData->CmdLists[n];
        const ImDrawVert* vtx = list->VtxBuffer.Data;
        const ImDrawIdx*  idx = list->IdxBuffer.Data;

        for (int ci = 0; ci < list->CmdBuffer.Size; ++ci) {
            const ImDrawCmd& cmd = list->CmdBuffer[ci];

            // 用户回调（如自定义渲染）在软件后端下无法执行，跳过
            if (cmd.UserCallback) continue;

            const float cx0 = std::max(cmd.ClipRect.x, 0.0f);
            const float cy0 = std::max(cmd.ClipRect.y, 0.0f);
            const float cx1 = std::min(cmd.ClipRect.z, static_cast<float>(fbW));
            const float cy1 = std::min(cmd.ClipRect.w, static_cast<float>(fbH));
            if (cx0 >= cx1 || cy0 >= cy1) continue;

            // 只有字体图集一种纹理；其它纹理按无纹理处理
            const bool hasTex = (cmd.GetTexID() != nullptr);

            for (unsigned int ei = 0; ei + 2 < cmd.ElemCount; ei += 3) {
                const ImDrawIdx i0 = idx[cmd.IdxOffset + ei + 0];
                const ImDrawIdx i1 = idx[cmd.IdxOffset + ei + 1];
                const ImDrawIdx i2 = idx[cmd.IdxOffset + ei + 2];
                const ImDrawVert& a = vtx[i0];
                const ImDrawVert& b = vtx[i1];
                const ImDrawVert& c = vtx[i2];

                rasterTriangle(bmp,
                    a.pos.x, a.pos.y, a.uv.x, a.uv.y, a.col,
                    b.pos.x, b.pos.y, b.uv.x, b.uv.y, b.col,
                    c.pos.x, c.pos.y, c.uv.x, c.uv.y, c.col,
                    fontPixels, fontW, fontH, hasTex,
                    cx0, cy0, cx1, cy1);
            }
        }
    }
}

bool writePPM(const std::string& path, const Bitmap& bmp) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    std::fprintf(f, "P6\n%d %d\n255\n", bmp.width, bmp.height);
    for (std::size_t i = 0; i < bmp.pixels.size(); i += 4) {
        std::uint8_t rgb[3] = { bmp.pixels[i], bmp.pixels[i + 1], bmp.pixels[i + 2] };
        std::fwrite(rgb, 1, 3, f);
    }
    std::fclose(f);
    return true;
}

bool writeBMP(const std::string& path, const Bitmap& bmp) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;

    const int w = bmp.width, h = bmp.height;
    const std::uint32_t rowSize = static_cast<std::uint32_t>(w) * 4;
    const std::uint32_t dataSize = rowSize * h;

    // BMP 文件头 + DIB 头（BITMAPINFOHEADER）
    std::uint8_t header[54] = {};
    header[0] = 'B'; header[1] = 'M';
    auto put32 = [&](int off, std::uint32_t v) {
        header[off + 0] = static_cast<std::uint8_t>(v & 0xFF);
        header[off + 1] = static_cast<std::uint8_t>((v >> 8) & 0xFF);
        header[off + 2] = static_cast<std::uint8_t>((v >> 16) & 0xFF);
        header[off + 3] = static_cast<std::uint8_t>((v >> 24) & 0xFF);
    };
    put32(2, 54 + dataSize);
    put32(10, 54);            // 像素数据偏移
    put32(14, 40);            // DIB 头大小
    put32(18, static_cast<std::uint32_t>(w));
    put32(22, static_cast<std::uint32_t>(h));
    header[26] = 1;           // 色彩平面
    header[28] = 32;          // 位深（BGRA）
    put32(34, dataSize);

    std::fwrite(header, 1, 54, f);

    // BMP 自下而上存储，且为 BGRA 顺序
    std::vector<std::uint8_t> row(rowSize);
    for (int y = h - 1; y >= 0; --y) {
        const std::uint8_t* src = bmp.pixels.data() + static_cast<std::size_t>(y) * rowSize;
        for (std::uint32_t x = 0; x < static_cast<std::uint32_t>(w); ++x) {
            row[x * 4 + 0] = src[x * 4 + 2];   // B
            row[x * 4 + 1] = src[x * 4 + 1];   // G
            row[x * 4 + 2] = src[x * 4 + 0];   // R
            row[x * 4 + 3] = src[x * 4 + 3];   // A
        }
        std::fwrite(row.data(), 1, rowSize, f);
    }
    std::fclose(f);
    return true;
}

} // namespace soft
} // namespace gr
